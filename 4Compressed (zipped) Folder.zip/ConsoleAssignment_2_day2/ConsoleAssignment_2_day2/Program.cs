﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleAssignment_2_day2
{
    class Program
    {
        static void Main(string[] args)
        {

            public void Getdata()
            {

                Console.WriteLine("DO YOU WANT TO PLACE AN ORDER?");
                Console.WriteLine("YES/NO");
                bool flag = Convert.ToBoolean(Console.ReadLine());
                    
                 if(flag)

                 {
                     Console.WriteLine("ENTER YOUR NAME:");
                     string name = Console.ReadLine();

                     Console.WriteLine("ENTER THE ITEM ID:");
                     int id = Convert.ToInt32(Console.ReadLine());

                     Console.WriteLine("ENTER ITEM QUANTITY:");
                     int quant = Convert.ToInt32(Console.ReadLine());

                     Console.WriteLine("ENTER THE ITEM PRICE:");
                     int price = Convert.ToInt32(Console.ReadLine());

                     Console.WriteLine("YOUR ORDER VALUE IS::");
                     int value = quant * price;

                     Console.WriteLine(value);
                                     
                     public int orderid;



                Order obj = new Order(name,id,quant,price,value,orderid);
    }
            }
        
}
    
}

}
