﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Runtime.Serialization.Json;//add reference system.seriliasition

namespace client_REST
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_Click_Click(object sender, EventArgs e)
        {
            WebClient client_Order = new WebClient();

            string address = "http://localhost:63930/Service_REST/Service.svc/myrestservice/FindOrder/1000" + txt_Click.Text;

            client_Order.OpenReadCompleted += new OpenReadCompletedEventHandler(client_Order_OpenReadCompleted);

            client_Order.OpenReadAsync(new Uri(address, UriKind.Absolute));
        }

        void client_Order_OpenReadCompleted(object sender, OpenReadCompletedEventArgs e)
        {
            DataContractJsonSerializer json = new DataContractJsonSerializer(typeof(Order));

            Order obj = json.ReadObject(e.Result) as Order;

            MessageBox.Show(obj.OrderID + " " + obj.OrderAmount);
                
        }

        private void button1_Click(object sender, EventArgs e)
        {
            WebClient client_getOrder = new WebClient();

            string address = "http://localhost:63930/Service_REST/Service.svc/myrestservice/GetOrder/ABC" + txt_Click.Text;

            client_getOrder.OpenReadCompleted += new OpenReadCompletedEventHandler(client_getOrder_OpenReadCompleted);
            client_getOrder.OpenReadAsync(new Uri(address, UriKind.Absolute));
         }

        void client_getOrder_OpenReadCompleted(object sender, OpenReadCompletedEventArgs e)
        {
            DataContractJsonSerializer json = new DataContractJsonSerializer(typeof(List<Order>));

            List<Order> obj = json.ReadObject(e.Result) as List<Order>;

            gv.DataSource = obj;
            

        }
    }
}
