﻿namespace client_REST
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_Click = new System.Windows.Forms.TextBox();
            this.btn_Click = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.gv = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.gv)).BeginInit();
            this.SuspendLayout();
            // 
            // txt_Click
            // 
            this.txt_Click.Location = new System.Drawing.Point(102, 3);
            this.txt_Click.Name = "txt_Click";
            this.txt_Click.Size = new System.Drawing.Size(100, 20);
            this.txt_Click.TabIndex = 5;
            // 
            // btn_Click
            // 
            this.btn_Click.Location = new System.Drawing.Point(21, 29);
            this.btn_Click.Name = "btn_Click";
            this.btn_Click.Size = new System.Drawing.Size(75, 23);
            this.btn_Click.TabIndex = 9;
            this.btn_Click.Text = "CLICK";
            this.btn_Click.UseVisualStyleBackColor = true;
            this.btn_Click.Click += new System.EventHandler(this.btn_Click_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(209, 29);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 10;
            this.button1.Text = "CLICK";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // gv
            // 
            this.gv.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.gv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gv.Location = new System.Drawing.Point(21, 67);
            this.gv.Name = "gv";
            this.gv.Size = new System.Drawing.Size(263, 163);
            this.gv.TabIndex = 11;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(306, 263);
            this.Controls.Add(this.gv);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btn_Click);
            this.Controls.Add(this.txt_Click);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.gv)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_Click;
        private System.Windows.Forms.Button btn_Click;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DataGridView gv;
    }
}

