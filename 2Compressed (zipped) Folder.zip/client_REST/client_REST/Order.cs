﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace client_REST
{
    public class Order
    {

        
        public int OrderID { set; get; }

        
        public string CustomerName { set; get; }

        
        public int OrderAmount { set; get; }

      
        public string OrderDetails { set; get; }
    }
}
