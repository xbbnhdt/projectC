﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_abstract_accounts
{
    class Current:Account
    {
         public Current(int accountid, string customername, int accountbalance)
            : base(accountid,customername, accountbalance)
        { }

         public override bool Withdraw(int amt)
        {
             accountbal = accountbal - amt;
             return true;
        }

        public override bool Deposit(int amt)
        {
            accountbal = accountbal + amt;
            return true;
        }
    }
}
