﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_abstract_accounts
{
    class Saving : Account
    {

        public Saving(int accountid, string customername, int accountbalance)
            : base(accountid,customername, accountbalance)
        { }
        public override bool Withdraw(int amt)
        {
            if ((accountbal - amt) >= 500)
            {
                accountbal = accountbal - amt;
                return true;
            }

            else
            {
                return false;
            }
        }

        public override bool Deposit(int amt)
        {
            accountbal = accountbal + amt + 100;
            return true;
        }
       
    }
}
