﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_abstract_accounts
{
    class Program
    {
        static void Main(string[] args)
        {

            int accountid;
            string customername;
            int accountbalance;

            Console.WriteLine("enter customer name");
            customername = Console.ReadLine();
            Console.WriteLine("enter accountid");
            accountid = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter account balance");
            accountbalance = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter account type");
            string type = Console.ReadLine();
            Account obj;

            if (type == "saving")
            {
                obj = new Saving(accountid,customername, accountbalance);
            }
            else
            {
                obj = new Current(accountid,customername, accountbalance);
            }


            int bal = obj.Getbalance();
            Console.WriteLine("balance:"+bal);
            obj.Deposit(2500);
            bal=obj.Getbalance();
                Console.WriteLine("bal:"+bal);
            obj.Withdraw(2000);
            bal=obj.Getbalance();
            Console.WriteLine("bal:" + bal);
            obj.stoppayment();
            Console.ReadLine();  


        }
    }
}
