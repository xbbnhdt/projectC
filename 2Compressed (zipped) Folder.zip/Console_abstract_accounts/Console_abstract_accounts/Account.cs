﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_abstract_accounts
{
    abstract class Account
    {

        protected int accountid;
        protected string customername;
      protected  int accountbal;
      public Account(int accountid, string customername, int accountbal)
      {
          this.accountid = accountid;
          this.accountbal = accountbal;
          this.customername = customername;
          Console.WriteLine("object created");
      
      }
      public void stoppayment()
      { 
        Console.WriteLine("stop payment");
      }

      public int Getbalance()
      {
          return accountbal;
      }
      public void Getstatement()
      {
          Console.WriteLine("Bank statement");
      }
      public abstract bool Withdraw(int amt);
        public abstract bool Deposit(int amt);

    }
}
