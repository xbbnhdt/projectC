﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_day3_op2
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
