﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_assignment3
{
    class Order
    {
        int orderid;
        string custname;
        int itemqty;
        int itemprice;


    }
}
