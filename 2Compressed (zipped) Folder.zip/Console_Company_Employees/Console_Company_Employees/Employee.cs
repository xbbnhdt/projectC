﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_Company_Employees
{
    class Employee
    {
        public delegate void delleave(int Empid, string message);//delegate definition
        public event delleave evt_leave_request;//event definition
        int Empid;
        public void request_leave(string message)
        {
            if (evt_leave_request != null)
            {
                evt_leave_request(Empid, message);//event fire
            }
        }
        bool leave_status = false;
        public bool pstatus
        {
            get
            {
                return leave_status;
            }
        }
        public void Leave_Approval()
        {
            
                leave_status = true;
           
        }
       


        public int pEmpid
        {
            get
            { return Empid; }
        }
        string Empname;
        string EmpCity;

        public Employee(int Empid, string Empname, string EmpCity)
        {

            this.Empid = Empid;
            this.EmpCity = EmpCity;
            this.Empname = Empname;
        }
        
        
        public override string ToString()
        {
            return Empid+" "+Empname+" "+EmpCity;
        }


    }
}
