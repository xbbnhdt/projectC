﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_Company_Employees
{
    class Program
    {
        static void Main(string[] args)
        {

            Company comp = new Company(1001, "INAUTIX");
            bool flag = true;
            while (flag)
            {

                Console.WriteLine("add: 1, Remove: 2, find: 3, Show: 4, Exit:5, company leave approval: 6");
                int opt = Convert.ToInt32(Console.ReadLine());
                switch (opt)
                {

                    case 1:

                        Console.WriteLine("enter employee id");
                        int empid = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("enter employee name");
                        string empname = Console.ReadLine();
                        Console.WriteLine("enter employee city");
                        string empcity = Console.ReadLine();
                        Employee obj = new Employee(empid, empname, empcity);
                        comp.AddEmployee(obj);
                        Console.WriteLine("Employee added successfully");
                        break;


                    case 2:
                        Console.WriteLine("enter empid for removing");
                        int emid = Convert.ToInt32(Console.ReadLine());
                        bool status = comp.RemoveEmployee(emid);
                        if (status == true)
                        {
                            Console.WriteLine("employee removed");
                        }
                        else
                        {
                            Console.WriteLine("employee not found");
                        }
                        break;



                    case 3:

                        Console.WriteLine("enter empid for searching");
                        int eid = Convert.ToInt32(Console.ReadLine());
                        Employee emp = comp.SearchEmployee(eid);
                        if (emp == null)
                        {
                            Console.WriteLine("employee not found");

                        }
                        else{
                               Console.WriteLine("enter 1:, 2: Leave Request");
                               int option = Convert.ToInt32(Console.ReadLine());
                                if (option == 1)
                                  {
                                     Console.WriteLine(emp.ToString());
                                  }
                                   else
                                       {
                                             Console.WriteLine("enter reason");
                                             string reason = Console.ReadLine();
                                             emp.request_leave(reason);
                                       }
                        }
              
                        /*else
                        {
                            Console.WriteLine(emp.ToString());
                        }*/
                        break;

                    case 4:

                        comp.ShowEmployee();
                        break;


                    case 5:

                        flag = false;
                        break;

                    case 6:
                        comp.employee_leave_request_approval();
                        break;


                }


                Console.ReadLine();


            }
        }
    }
}