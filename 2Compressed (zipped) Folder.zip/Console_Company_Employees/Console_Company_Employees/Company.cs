﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_Company_Employees
{
    class Company
    {
        int Companyid;
        string Companyname;
        List<Employee> emplist = new List<Employee>();
        List<Employee> emplist_leave_request = new List<Employee>();
        public Company(int Companyid, string Companyname)
        {
            this.Companyid = Companyid;
            this.Companyname = Companyname;

        }

        public void notify(int Empid, string message)
        {
            Console.WriteLine("Company:" + Empid + " : " + message);
            emplist_leave_request.Add(SearchEmployee(Empid));
        }

        public void employee_leave_request_approval()
        {
            foreach (Employee e in emplist_leave_request)
            {
                e.Leave_Approval();
                Console.WriteLine("approved by company:" + e.pEmpid);
            }
            emplist_leave_request.Clear();
        }


        public void AddEmployee(Employee emp)
        {
            emplist.Add(emp);
            emp.evt_leave_request += new Employee.delleave(notify);
        }

        public bool RemoveEmployee(int Empid)
        {

            foreach (Employee e in emplist)
            {
                if (e.pEmpid == Empid)
                {
                    emplist.Remove(e);
                    return true;
                }

            } return false;
        }

        public Employee SearchEmployee(int Empid)
        {
            foreach (Employee e in emplist)
            {
                if (e.pEmpid == Empid)
                {
                    return e;
                }
            }
            return null;
        }

        public void ShowEmployee()
        {
            foreach (Employee e in emplist)
            {
                Console.WriteLine(e.ToString());
            }
        }
    }
}
