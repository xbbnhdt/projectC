﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.ServiceModel;


namespace ClientOrders
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        ServiceReference1.ServiceClient proxy = new ServiceReference1.ServiceClient("WSHttpBinding_IService");

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void btn_PlaceOrder_Click(object sender, EventArgs e)
        {
            try
            {
                ServiceReference1.Orders obj = new ServiceReference1.Orders();

                obj.CustomerName = txt_CustomerName.Text;
                obj.OrderCity = txt_OrderCity.Text;
                obj.OrderAmount = Convert.ToInt32(txt_OrderAmount.Text);

                int OrderID = proxy.AddOrders(obj);

                MessageBox.Show("ORDER" + "" + OrderID + "" + "ADDED SUCCESSFULLY");

                lbl_OrderID.Text = OrderID.ToString();
            }
            catch (FaultException<ServiceReference1.ErrorInfo> exp)
            {

                MessageBox.Show(exp.Detail.ErrorID + "   " + exp.Detail.ErrorDate + "   " + exp.Detail.ErrorDetails);
            }

        }

        private void btn_ShowOrders_Click(object sender, EventArgs e)
        {
            proxy.GetOrdersCompleted += new EventHandler<ServiceReference1.GetOrdersCompletedEventArgs>(proxy_GetOrdersCompleted);
            proxy.GetOrdersAsync(txt_SearchName.Text);

            
        }

        void proxy_GetOrdersCompleted(object sender, ServiceReference1.GetOrdersCompletedEventArgs e)
        {

            if (e.Error == null)
            {
                gv.DataSource = e.Result.ToList();
            }
            else
            {
                MessageBox.Show(e.Error.Message);
            }
        }

       
    }
}
