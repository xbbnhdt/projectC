﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Transactions;

namespace Client_Transaction
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btn_BuyNow_Click(object sender, EventArgs e)
        {
            try{
            using (TransactionScope scope = new TransactionScope())
            {
                ServiceReference1.ServiceClient bank_proxy = new ServiceReference1.ServiceClient("WSHttpBinding_IService");

                int TransactionID = bank_proxy.MakePayment(Convert.ToInt32(txt_AccountNumber.Text), Convert.ToInt32(txt_ProductPrice.Text));

                ServiceReference2.ServiceClient order_Proxy = new ServiceReference2.ServiceClient("WSHttpBinding_IService1");

                int OrderID = order_Proxy.PlaceOrder(Convert.ToInt32(txt_ProductID.Text), Convert.ToInt32(txt_ProductPrice.Text), TransactionID, txt_BankName.Text);

                scope.Complete();
                MessageBox.Show("ORDER PLACED SUCCESSFULLY!!!!" + "  " + "YOUR ORDER ID IS:" + "  " + OrderID + "  " + "YOUR TRANSACTION ID IS:" + "  " + TransactionID);
            }
            }
                catch(Exception exp)
            {
                    MessageBox.Show("ORDER CANCELLED"+ " " + exp.Message);
                }
          

       
    }
    }
}