﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_day3_oop2
{
    class Customer_Special
    {
        string customer

    }
}
