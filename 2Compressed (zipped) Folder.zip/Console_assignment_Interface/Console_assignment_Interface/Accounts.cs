﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_assignment_Interface
{
    class Accounts
    {
        public void accounts(iAccounts obj)
        {
            double salary = obj.GetEmployeeSalary();
            Console.WriteLine(salary);
            int AccNo = obj.GetEmployeeAccountNo();
            Console.WriteLine(AccNo);
            int id = obj.GetEmployeeId();
            Console.WriteLine(id);
        }
    }
}