﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_assignment_Interface
{
    class Manager
    {
        public void manager(iManager obj)
        {
            int id = obj.GetEmployeeId();
            Console.WriteLine(id);
            int exp = obj.GetEmployeeExperience();
            Console.WriteLine(exp);
            string det = obj.GetEmployeeProjectDetails();
            Console.WriteLine(det);

        }




    }
}
