﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_assignment_Interface
{
    class Program
    {
        static void Main(string[] args)
        {
            bool flag = true;
            while (flag)
            {


                Employee e = new Employee();

                Console.WriteLine("enter employee id");
                e.EmployeeID = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("enter employee name");
                e.EmployeeName = Console.ReadLine();
                Console.WriteLine("enter employee city");
                e.EmployeeCity = Console.ReadLine();
                Console.WriteLine("enter employee salary");
                e.EmployeeSalary = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("enter employee address");
                e.EmployeeAdress = Console.ReadLine();
                Console.WriteLine("enter employee projectdetails");
                e.EmployeeProjectDetails = Console.ReadLine();
                Console.WriteLine("enter employee experience");
                e.EmployeeExperience = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("enter employee accountnumber");
                e.EmployeeAccountNumber = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("enter employee bankname");
                e.EmployeeBankName = Console.ReadLine();
                Console.WriteLine("enter employee age");
                e.EmployeeAge = Convert.ToInt32(Console.ReadLine());


                Console.WriteLine("1) HR");
                Console.WriteLine("2) Manager");
                Console.WriteLine("3) Accounts");
                Console.WriteLine("4) Exit");

                int opt = Convert.ToInt32(Console.ReadLine());

                switch(opt)
                {
                case 1:

                HR a = new HR();
                a.Hr_Details(e);
                break;


                case 2:
                Manager m = new Manager();
                m.manager(e);
                break;

                case 3:

                Accounts s = new Accounts();
                s.accounts(e);
                break;

                    case 4:
                flag=false;
                break;

                }
                Console.ReadLine();




            }
           
            }


        }
    }

