﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_assignment_Interface
{
    class HR
    {
        public void Hr_Details(iHR obj)
        {
            string address = obj.GetEmployeeAddress();               
            Console.WriteLine(address);
            double salary = obj.GetEmployeeSalary();
            Console.WriteLine(salary);
            int id = obj.GetEmployeeId();
            Console.WriteLine(id);


        }
       

    }
}
