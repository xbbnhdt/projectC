﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_assignment_Interface
{
    class Employee : iAccounts, iHR, iManager
    {
        public int EmployeeID;
        public string EmployeeName;
        public string EmployeeCity;
        public double EmployeeSalary;
        public string EmployeeAdress;
        public string EmployeeProjectDetails;
        public int EmployeeExperience;
        public int EmployeeAccountNumber;
        public string EmployeeBankName;
        public int EmployeeAge;





        public double GetEmployeeSalary()
        {
            return EmployeeSalary;
        }

        public int GetEmployeeAccountNo()
        {
            return EmployeeAccountNumber;
        }

        public int GetEmployeeId()
        {
            return EmployeeID;
        }

        public string GetEmployeeAddress()
        {
            return EmployeeAdress;
        }


        public int GetEmployeeExperience()
        {
            return EmployeeExperience;
        }

        public string GetEmployeeProjectDetails()
        {
            return EmployeeProjectDetails;
        }
    }
}
