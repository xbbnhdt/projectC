﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Client_Instancing
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        ServiceReference1.ServiceClient proxy = new ServiceReference1.ServiceClient("WSHttpBinding_IService");
        

        private void button1_Click(object sender, EventArgs e)
        {
            int ret = proxy.DetCountValue();
            MessageBox.Show(ret.ToString());
        }
    }
}
