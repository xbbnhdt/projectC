﻿namespace Client_Duplex
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_GetData = new System.Windows.Forms.Button();
            this.lst_Data = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btn_GetData
            // 
            this.btn_GetData.Location = new System.Drawing.Point(264, 63);
            this.btn_GetData.Name = "btn_GetData";
            this.btn_GetData.Size = new System.Drawing.Size(75, 23);
            this.btn_GetData.TabIndex = 0;
            this.btn_GetData.Text = "button1";
            this.btn_GetData.UseVisualStyleBackColor = true;
            this.btn_GetData.Click += new System.EventHandler(this.btn_GetData_Click);
            // 
            // lst_Data
            // 
            this.lst_Data.FormattingEnabled = true;
            this.lst_Data.Location = new System.Drawing.Point(237, 165);
            this.lst_Data.Name = "lst_Data";
            this.lst_Data.Size = new System.Drawing.Size(120, 95);
            this.lst_Data.TabIndex = 1;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(748, 396);
            this.Controls.Add(this.lst_Data);
            this.Controls.Add(this.btn_GetData);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_GetData;
        private System.Windows.Forms.ListBox lst_Data;
    }
}

