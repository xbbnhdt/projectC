﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Client_Calculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_Add_Click(object sender, EventArgs e)
        {
            int num1 = Convert.ToInt32(txt_num1.Text);
            int num2 = Convert.ToInt32(txt_num2.Text);

            ServiceReference1.ServiceClient proxy = new ServiceReference1.ServiceClient("WSHttpBinding_IService");
            int result = proxy.GetSum(num1, num2);
            proxy.Close();
            MessageBox.Show("SUM :" + result);
        }

        private void btn_Sub_Click(object sender, EventArgs e)
        {

            int num1 = Convert.ToInt32(txt_num1.Text);
            int num2 = Convert.ToInt32(txt_num2.Text);

            ServiceReference1.ServiceClient proxy = new ServiceReference1.ServiceClient("WSHttpBinding_IService");
            int result = proxy.GetSubtraction(num1, num2);
            proxy.Close();
            MessageBox.Show("DIFFERENCE :" + result);
        }

        private void btn_mult_Click(object sender, EventArgs e)
        {

            int num1 = Convert.ToInt32(txt_num1.Text);
            int num2 = Convert.ToInt32(txt_num2.Text);

            ServiceReference1.ServiceClient proxy = new ServiceReference1.ServiceClient("WSHttpBinding_IService");
            int result = proxy.GetMultiplication(num1, num2);
            proxy.Close();
            MessageBox.Show("PRODUCT :" + result);
        }

        private void btn_div_Click(object sender, EventArgs e)
        {

            int num1 = Convert.ToInt32(txt_num1.Text);
            int num2 = Convert.ToInt32(txt_num2.Text);

            ServiceReference1.ServiceClient proxy = new ServiceReference1.ServiceClient("WSHttpBinding_IService");
            int result = proxy.GetDivision(num1, num2);
            proxy.Close();
            MessageBox.Show("RESULT :" + result);

        }
    }
}
