﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.ServiceModel;

namespace Client
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        ServiceReference1.ServiceClient proxy = new ServiceReference1.ServiceClient("WSHttpBinding_IService");

        private void btn_AddCustomer_Click(object sender, EventArgs e)
        {
            try
            {
                ServiceReference1.Customer obj = new ServiceReference1.Customer();

                obj.CustomeeName = txt_CustomerName.Text;
                obj.CustomeeCity = txt_CustomerCity.Text;

                int CustomerID = proxy.AddCustomer(obj);

                MessageBox.Show("CUSTOME" + "" + CustomerID + "" + "ADDED SUCCESSFULLY");

                txt_CustomerID.Text = CustomerID.ToString();

            }
            catch (FaultException<ServiceReference1.ErrorInfo>exp)
            {

                MessageBox.Show(exp.Detail.ErrorID + "           "+ exp.Detail.ErrorDate+"            "+exp.Detail.ErrorDetails);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btn_GetCustomer_Click(object sender, EventArgs e)
        {
            proxy.GetCustomerCompleted += new EventHandler<ServiceReference1.GetCustomerCompletedEventArgs>(proxy_GetCustomerCompleted);
            proxy.GetCustomerAsync(txt_City.Text);
        }

        void proxy_GetCustomerCompleted(object sender, ServiceReference1.GetCustomerCompletedEventArgs e)
        {

            if (e.Error == null)
            {
                dataGridView1.DataSource = e.Result.ToList();
            }
            else
            {
                MessageBox.Show(e.Error.Message);
            }
        }
    }
}
