﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Client_MessagePattern
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_GetWcf_Click(object sender, EventArgs e)
        {
            ServiceReference2.ServiceClient proxy = new ServiceReference2.ServiceClient("WSHttpBinding_IService");


            proxy.UpdateData(txt_GetWcf.Text);
            MessageBox.Show("some other task");
        }
    }

}