﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Class_library
{
    public class Sum
    {
        public int GetSum(int num1, int num2)
        {
            int total = num1 + num2+500;
            return total;
        }
    }
}
