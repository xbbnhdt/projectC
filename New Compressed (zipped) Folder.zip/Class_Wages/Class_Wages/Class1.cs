﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Class_Wages
{
    public class Class1
    {

        int salary = Convert.ToInt32(Console.ReadLine());
        int workingdays = Convert.ToInt32(Console.ReadLine());

        public int CalculateTotalWage(int salary, int workingdays)
        {
            int total = salary * workingdays;
            return total;

        }
    }
}
