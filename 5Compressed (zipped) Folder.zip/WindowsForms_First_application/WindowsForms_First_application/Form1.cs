﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsForms_First_application
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            string userid = txt_loginid.Text;
            string passeword = txt_password.Text;
            if (userid == "")
            {
                MessageBox.Show("enter lodin id");
            }
            else if (passeword == "")
            {
                MessageBox.Show("enter password");
            }
            else
            {

                if (userid == "user1" && passeword == "123@s")
                {
                    MessageBox.Show("Valid Data");
                    frm_home obj=new frm_home();
                    obj.Show();

                }
                else
                {
                    MessageBox.Show("Invalid id or password");
                }





            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
    }