﻿namespace WindowsForms_First_application
{
    partial class frm_home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lst_City = new System.Windows.Forms.ListBox();
            this.btn_getcity = new System.Windows.Forms.Button();
            this.cmb_item_id = new System.Windows.Forms.ComboBox();
            this.chk_orderstatus = new System.Windows.Forms.CheckBox();
            this.rdb_male = new System.Windows.Forms.RadioButton();
            this.rdb_female = new System.Windows.Forms.RadioButton();
            this.SuspendLayout();
            // 
            // lst_City
            // 
            this.lst_City.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lst_City.FormattingEnabled = true;
            this.lst_City.ItemHeight = 18;
            this.lst_City.Location = new System.Drawing.Point(12, 157);
            this.lst_City.Name = "lst_City";
            this.lst_City.Size = new System.Drawing.Size(120, 94);
            this.lst_City.TabIndex = 0;
            // 
            // btn_getcity
            // 
            this.btn_getcity.Font = new System.Drawing.Font("Modern No. 20", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_getcity.Location = new System.Drawing.Point(220, 30);
            this.btn_getcity.Name = "btn_getcity";
            this.btn_getcity.Size = new System.Drawing.Size(131, 23);
            this.btn_getcity.TabIndex = 1;
            this.btn_getcity.Text = "CHOOSE CITY";
            this.btn_getcity.UseVisualStyleBackColor = true;
            this.btn_getcity.Click += new System.EventHandler(this.btn_getcity_Click);
            // 
            // cmb_item_id
            // 
            this.cmb_item_id.Font = new System.Drawing.Font("Modern No. 20", 8.999999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_item_id.FormattingEnabled = true;
            this.cmb_item_id.Location = new System.Drawing.Point(26, 78);
            this.cmb_item_id.Name = "cmb_item_id";
            this.cmb_item_id.Size = new System.Drawing.Size(120, 23);
            this.cmb_item_id.TabIndex = 2;
            this.cmb_item_id.SelectedIndexChanged += new System.EventHandler(this.cmb_item_id_SelectedIndexChanged);
            // 
            // chk_orderstatus
            // 
            this.chk_orderstatus.AutoSize = true;
            this.chk_orderstatus.Font = new System.Drawing.Font("Modern No. 20", 8.999999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk_orderstatus.Location = new System.Drawing.Point(462, 306);
            this.chk_orderstatus.Name = "chk_orderstatus";
            this.chk_orderstatus.Size = new System.Drawing.Size(108, 19);
            this.chk_orderstatus.TabIndex = 3;
            this.chk_orderstatus.Text = "COMPLETED";
            this.chk_orderstatus.UseVisualStyleBackColor = true;
            // 
            // rdb_male
            // 
            this.rdb_male.AutoSize = true;
            this.rdb_male.Location = new System.Drawing.Point(203, 119);
            this.rdb_male.Name = "rdb_male";
            this.rdb_male.Size = new System.Drawing.Size(54, 17);
            this.rdb_male.TabIndex = 4;
            this.rdb_male.TabStop = true;
            this.rdb_male.Text = "MALE";
            this.rdb_male.UseVisualStyleBackColor = true;
            this.rdb_male.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // rdb_female
            // 
            this.rdb_female.AutoSize = true;
            this.rdb_female.Location = new System.Drawing.Point(360, 119);
            this.rdb_female.Name = "rdb_female";
            this.rdb_female.Size = new System.Drawing.Size(67, 17);
            this.rdb_female.TabIndex = 5;
            this.rdb_female.TabStop = true;
            this.rdb_female.Text = "FEMALE";
            this.rdb_female.UseVisualStyleBackColor = true;
            // 
            // frm_home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(582, 347);
            this.Controls.Add(this.rdb_female);
            this.Controls.Add(this.rdb_male);
            this.Controls.Add(this.chk_orderstatus);
            this.Controls.Add(this.cmb_item_id);
            this.Controls.Add(this.btn_getcity);
            this.Controls.Add(this.lst_City);
            this.Name = "frm_home";
            this.Text = "frm_home";
            this.Load += new System.EventHandler(this.frm_home_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lst_City;
        private System.Windows.Forms.Button btn_getcity;
        private System.Windows.Forms.ComboBox cmb_item_id;
        private System.Windows.Forms.CheckBox chk_orderstatus;
        private System.Windows.Forms.RadioButton rdb_male;
        private System.Windows.Forms.RadioButton rdb_female;
    }
}