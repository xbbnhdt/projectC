﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsForms_First_application
{
    public partial class frm_home : Form
    {
        public frm_home()
        {
            InitializeComponent();
        }

        private void frm_home_Load(object sender, EventArgs e)
        {
            lst_City.Items.Add("CHENNAI");
            lst_City.Items.Add("PUNE");
            lst_City.Items.Add("SURAT");
            cmb_item_id.Items.Add("1");
            cmb_item_id.Items.Add("2");
            cmb_item_id.Items.Add("3");
        }

        private void cmb_item_id_SelectedIndexChanged(object sender, EventArgs e)
        {
           

        }

        private void btn_getcity_Click(object sender, EventArgs e)
        {

            string gender = "";
            if (rdb_male.Checked)
            {
                gender = "MALE";
                
            }
            else if (rdb_female.Checked)
            {
                gender = "FEMALE";
            }


            if (chk_orderstatus.Checked)
            {
                MessageBox.Show("ORDER COMPLETED SUCCESSFULLY");
            }
            else
            {

                MessageBox.Show("UNSUCCESSFUL!!");
            }
            string CITY = lst_City.Text;
            
            if (lst_City.Text == "")
            {
                MessageBox.Show("Choose a City");
            }
            else {


                MessageBox.Show(CITY);
            
            }
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        

      
    }
}
 