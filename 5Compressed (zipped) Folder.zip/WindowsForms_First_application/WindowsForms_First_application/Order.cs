﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WindowsForms_First_application
{
    class Order
    {

        string orderid;
        string customername;
        string itemid;
        string itemqty;
        string itemprice;
        string delivraddress;
        string ordercity;
        string orderdate;
        string paymentoption;
        string placeorder;
        string reset;


    }
}
