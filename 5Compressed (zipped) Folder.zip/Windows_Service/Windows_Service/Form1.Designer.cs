﻿namespace Windows_Service
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_GetSalary = new System.Windows.Forms.Button();
            this.DAYS = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_Sal = new System.Windows.Forms.TextBox();
            this.txt_Days = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btn_GetSalary
            // 
            this.btn_GetSalary.Location = new System.Drawing.Point(108, 288);
            this.btn_GetSalary.Name = "btn_GetSalary";
            this.btn_GetSalary.Size = new System.Drawing.Size(315, 68);
            this.btn_GetSalary.TabIndex = 0;
            this.btn_GetSalary.Text = "GET SALARY";
            this.btn_GetSalary.UseVisualStyleBackColor = true;
            this.btn_GetSalary.Click += new System.EventHandler(this.btn_GetSalary_Click);
            // 
            // DAYS
            // 
            this.DAYS.AutoSize = true;
            this.DAYS.Location = new System.Drawing.Point(85, 87);
            this.DAYS.Name = "DAYS";
            this.DAYS.Size = new System.Drawing.Size(36, 13);
            this.DAYS.TabIndex = 1;
            this.DAYS.Text = "DAYS";
            this.DAYS.Click += new System.EventHandler(this.DAYS_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(85, 190);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "SALARY";
            // 
            // txt_Sal
            // 
            this.txt_Sal.Location = new System.Drawing.Point(323, 183);
            this.txt_Sal.Name = "txt_Sal";
            this.txt_Sal.Size = new System.Drawing.Size(100, 20);
            this.txt_Sal.TabIndex = 3;
            // 
            // txt_Days
            // 
            this.txt_Days.Location = new System.Drawing.Point(323, 80);
            this.txt_Days.Name = "txt_Days";
            this.txt_Days.Size = new System.Drawing.Size(100, 20);
            this.txt_Days.TabIndex = 4;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(519, 421);
            this.Controls.Add(this.txt_Days);
            this.Controls.Add(this.txt_Sal);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.DAYS);
            this.Controls.Add(this.btn_GetSalary);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_GetSalary;
        private System.Windows.Forms.Label DAYS;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_Sal;
        private System.Windows.Forms.TextBox txt_Days;
    }
}

