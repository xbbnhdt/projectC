﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Windows_ExceptionHandling
{
    class Test
    {
        public int GetSum(string str)
        {

            // con.Open();
            int i = 0;
            i = Convert.ToInt32(str);
            //const.Close();
            return i;
        }


    }
}
