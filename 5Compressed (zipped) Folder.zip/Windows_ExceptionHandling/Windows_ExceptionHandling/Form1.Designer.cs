﻿namespace Windows_ExceptionHandling
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_getvalue = new System.Windows.Forms.TextBox();
            this.btn_getvalue = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txt_getvalue
            // 
            this.txt_getvalue.Location = new System.Drawing.Point(121, 43);
            this.txt_getvalue.Name = "txt_getvalue";
            this.txt_getvalue.Size = new System.Drawing.Size(151, 20);
            this.txt_getvalue.TabIndex = 0;
            // 
            // btn_getvalue
            // 
            this.btn_getvalue.Location = new System.Drawing.Point(12, 43);
            this.btn_getvalue.Name = "btn_getvalue";
            this.btn_getvalue.Size = new System.Drawing.Size(103, 20);
            this.btn_getvalue.TabIndex = 1;
            this.btn_getvalue.Text = "GET VALUE";
            this.btn_getvalue.UseVisualStyleBackColor = true;
            this.btn_getvalue.Click += new System.EventHandler(this.btn_getvalue_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(284, 101);
            this.Controls.Add(this.btn_getvalue);
            this.Controls.Add(this.txt_getvalue);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_getvalue;
        private System.Windows.Forms.Button btn_getvalue;
    }
}

