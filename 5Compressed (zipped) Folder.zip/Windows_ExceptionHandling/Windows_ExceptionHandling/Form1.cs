﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Windows_ExceptionHandling
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_getvalue_Click(object sender, EventArgs e)
        {
            int i = 0;
            try
            {
               Test obj = new Test();

                i = obj.GetSum(txt_getvalue.Text);
                MessageBox.Show(i.ToString());
            }



            catch (NullReferenceException exp)
            {
                MessageBox.Show("Null Reference Error");
            }

            catch (Exception exp)
            {


                //MessageBox.Show(exp.Message);
                MessageBox.Show("Error in application");
            }
            finally
            {
                MessageBox.Show("mandatory messages");
            }

            MessageBox.Show("After Finally");
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        }

    }
}
