﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace Windows_Assignment_ADO
{
    public partial class Form1 : Form
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        public Form1()
        {

           


            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand con_city = new SqlCommand("select cityname from city", con);
            SqlDataReader dr = con_city.ExecuteReader();
            while (dr.Read())
            {
                cmb_empcity.Items.Add(dr.GetString(0));

            }


            con.Close();
        }

        private void btn_reset_Click(object sender, EventArgs e)
        {
            txt_empage.Text = "";
            txt_empDOJ.Text = "";
            txt_empid.Text = "";
            txt_empname.Text = "";
            cmb_empcity.Text = "";
            txt_emppassword.Text = "";
            
        }

        private void btn_addemp_Click(object sender, EventArgs e)
        {
            con.Open();

            SqlCommand con_emp_insert = new SqlCommand("insert employee values(@empname, @empcity, @empage,@emppassword, getdate())", con);
            con_emp_insert.Parameters.AddWithValue("@empname", txt_empname.Text);
            con_emp_insert.Parameters.AddWithValue("@empcity", cmb_empcity.Text);
            con_emp_insert.Parameters.AddWithValue("@empage", txt_empage.Text);
            con_emp_insert.Parameters.AddWithValue("@emppassword", txt_emppassword.Text);
            
            con_emp_insert.ExecuteNonQuery();
            SqlCommand con_empid = new SqlCommand("select @@identity", con);
            int empid = Convert.ToInt32(con_empid.ExecuteScalar());
            txt_empid.Text = empid.ToString();            
            con.Close();


        }

        private void lbl_emppassword_Click(object sender, EventArgs e)
        {

        }

        private void btn_updateemp_Click(object sender, EventArgs e)
        {
            con.Open();

            SqlCommand con_update_emp = new 
            SqlCommand("update employee set employeename=@empname,  employeepassword = @emppassword, employeecity = @empcity where employeeid = @empid", con);
            con_update_emp.Parameters.AddWithValue("@empname", txt_empname.Text);
            con_update_emp.Parameters.AddWithValue("@empcity", cmb_empcity.Text);
            con_update_emp.Parameters.AddWithValue("@empid", txt_empid.Text);
            con_update_emp.Parameters.AddWithValue("@emppassword", txt_emppassword.Text);
            int rowsaffected = con_update_emp.ExecuteNonQuery();

            con.Close();

            if (rowsaffected > 0)
            {
                MessageBox.Show("employee updated");
            }
            else
            {
                MessageBox.Show("employee not shown");
            }
        }

        private void btn_findemp_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand con_find_emp = new SqlCommand("Select * from employee where employeeid = @empid", con);
            con_find_emp.Parameters.AddWithValue("@empid", txt_empid.Text);
            SqlDataReader dr = con_find_emp.ExecuteReader();
            if (dr.Read())
            {
                txt_empid.Text = dr.GetInt32(0).ToString();
                txt_empname.Text = dr.GetString(1);
                cmb_empcity.Text = dr.GetString(2);
                txt_empage.Text = dr.GetInt32(3).ToString();
                txt_emppassword.Text = dr.GetString(4);


            }
            else
            {
                MessageBox.Show("employee not found");
            }
            con.Close();
        }

        private void cmb_empcity_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btn_exit_Click(object sender, EventArgs e)
        {
            frm_login obj = new frm_login();
            obj.Show();
        }






    }

}
