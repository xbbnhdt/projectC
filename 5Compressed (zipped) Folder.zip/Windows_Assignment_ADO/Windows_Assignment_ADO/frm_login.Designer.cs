﻿namespace Windows_Assignment_ADO
{
    partial class frm_login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_empid = new System.Windows.Forms.TextBox();
            this.txt_emppassword = new System.Windows.Forms.TextBox();
            this.btn_login = new System.Windows.Forms.Button();
            this.lbl_empid = new System.Windows.Forms.Label();
            this.lbl_emppassword = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txt_empid
            // 
            this.txt_empid.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_empid.Location = new System.Drawing.Point(163, 15);
            this.txt_empid.Name = "txt_empid";
            this.txt_empid.Size = new System.Drawing.Size(100, 25);
            this.txt_empid.TabIndex = 0;
            // 
            // txt_emppassword
            // 
            this.txt_emppassword.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_emppassword.Location = new System.Drawing.Point(163, 72);
            this.txt_emppassword.Name = "txt_emppassword";
            this.txt_emppassword.PasswordChar = '*';
            this.txt_emppassword.Size = new System.Drawing.Size(100, 25);
            this.txt_emppassword.TabIndex = 1;
            // 
            // btn_login
            // 
            this.btn_login.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_login.Location = new System.Drawing.Point(91, 133);
            this.btn_login.Name = "btn_login";
            this.btn_login.Size = new System.Drawing.Size(75, 23);
            this.btn_login.TabIndex = 2;
            this.btn_login.Text = "LOGIN";
            this.btn_login.UseVisualStyleBackColor = true;
            this.btn_login.Click += new System.EventHandler(this.btn_login_Click);
            // 
            // lbl_empid
            // 
            this.lbl_empid.AutoSize = true;
            this.lbl_empid.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_empid.Location = new System.Drawing.Point(27, 18);
            this.lbl_empid.Name = "lbl_empid";
            this.lbl_empid.Size = new System.Drawing.Size(115, 17);
            this.lbl_empid.TabIndex = 3;
            this.lbl_empid.Text = "EMPLOYEE ID";
            // 
            // lbl_emppassword
            // 
            this.lbl_emppassword.AutoSize = true;
            this.lbl_emppassword.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_emppassword.Location = new System.Drawing.Point(27, 75);
            this.lbl_emppassword.Name = "lbl_emppassword";
            this.lbl_emppassword.Size = new System.Drawing.Size(91, 17);
            this.lbl_emppassword.TabIndex = 4;
            this.lbl_emppassword.Text = "PASSWORD";
            // 
            // frm_login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(285, 179);
            this.Controls.Add(this.lbl_emppassword);
            this.Controls.Add(this.lbl_empid);
            this.Controls.Add(this.btn_login);
            this.Controls.Add(this.txt_emppassword);
            this.Controls.Add(this.txt_empid);
            this.Name = "frm_login";
            this.Text = "frm_login";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_empid;
        private System.Windows.Forms.TextBox txt_emppassword;
        private System.Windows.Forms.Button btn_login;
        private System.Windows.Forms.Label lbl_empid;
        private System.Windows.Forms.Label lbl_emppassword;
    }
}