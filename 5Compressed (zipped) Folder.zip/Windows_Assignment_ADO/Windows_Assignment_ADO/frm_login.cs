﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace Windows_Assignment_ADO
{
    public partial class frm_login : Form
    {
        public frm_login()
        {
            InitializeComponent();
        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
            SqlCommand con_login = new SqlCommand("select count(*) from employee where employeeid = @empid and employeepassword = @emppassword", con);
            con_login.Parameters.AddWithValue("@empid", txt_empid.Text);
            con_login.Parameters.AddWithValue("@emppassword", txt_emppassword.Text);
            con.Open();
            int count = Convert.ToInt32(con_login.ExecuteScalar());
            con.Close();
            if (count > 0)
            {
                
                Form1 obj = new Form1();
                obj.Show();


            }
            else
            {

                MessageBox.Show("WRONG ID OR PASSWORD");
            }
        }
    }
}
