﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Wpf_Lesson_One
{
    /// <summary>
    /// Interaction logic for win_Control.xaml
    /// </summary>
    public partial class win_Control : Window
    {
        public win_Control()
        {
            InitializeComponent();
        }

        private void s1_number_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {

            //if (s1_number_Value != null)
            {
                txt_number.Text = s1_number.Value.ToString();
            }

        }
    }
}
