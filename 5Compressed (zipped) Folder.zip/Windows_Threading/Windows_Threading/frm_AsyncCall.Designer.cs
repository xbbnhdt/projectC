﻿namespace Windows_Threading
{
    partial class frm_AsyncCall
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Async = new System.Windows.Forms.Button();
            this.lst_result = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btn_Async
            // 
            this.btn_Async.Location = new System.Drawing.Point(82, 12);
            this.btn_Async.Name = "btn_Async";
            this.btn_Async.Size = new System.Drawing.Size(123, 48);
            this.btn_Async.TabIndex = 0;
            this.btn_Async.Text = "ASYNC CALL";
            this.btn_Async.UseVisualStyleBackColor = true;
            this.btn_Async.Click += new System.EventHandler(this.button1_Click);
            // 
            // lst_result
            // 
            this.lst_result.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lst_result.FormattingEnabled = true;
            this.lst_result.ItemHeight = 24;
            this.lst_result.Location = new System.Drawing.Point(82, 99);
            this.lst_result.Name = "lst_result";
            this.lst_result.Size = new System.Drawing.Size(120, 76);
            this.lst_result.TabIndex = 1;
            // 
            // frm_AsyncCall
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.lst_result);
            this.Controls.Add(this.btn_Async);
            this.Name = "frm_AsyncCall";
            this.Text = "frm_AsyncCall";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_Async;
        private System.Windows.Forms.ListBox lst_result;
    }
}