﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
 using System.Threading;

namespace Windows_Threading
{
    public partial class frm2_thread : Form
    {
        public frm2_thread()
        {
            InitializeComponent();
        }

        int total;
        object obj = new object();
        public void sum()
        {
           
            //lock (obj) ;
            Monitor.Enter(this);
            int num1 = Convert.ToInt32(txt_thread1.Text);
            int num2 = Convert.ToInt32(txt_thread2.Text);
            total = num1 + num2;
            Thread.Sleep(5);
            MessageBox.Show("" + total);
            Monitor.Exit(this);
        }
           
        private void btn_thread1_Click(object sender, EventArgs e)
        {
            Thread th1 = new Thread(sum);
            th1.Start();
        }

        private void btn_thread2_Click(object sender, EventArgs e)
        {
            Thread th2 = new Thread(sum);
            th2.Start();

        }

        private void txt_thread1_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt_thread2_TextChanged(object sender, EventArgs e)
        {

        }

        private void frm2_thread_Load(object sender, EventArgs e)
        {

        }

       
    }
}
