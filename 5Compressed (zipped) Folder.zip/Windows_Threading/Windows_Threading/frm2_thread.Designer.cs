﻿namespace Windows_Threading
{
    partial class frm2_thread
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_thread1 = new System.Windows.Forms.Button();
            this.btn_thread2 = new System.Windows.Forms.Button();
            this.txt_thread1 = new System.Windows.Forms.TextBox();
            this.txt_thread2 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btn_thread1
            // 
            this.btn_thread1.Location = new System.Drawing.Point(30, 206);
            this.btn_thread1.Name = "btn_thread1";
            this.btn_thread1.Size = new System.Drawing.Size(75, 23);
            this.btn_thread1.TabIndex = 0;
            this.btn_thread1.Text = "THREAD1";
            this.btn_thread1.UseVisualStyleBackColor = true;
            this.btn_thread1.Click += new System.EventHandler(this.btn_thread1_Click);
            // 
            // btn_thread2
            // 
            this.btn_thread2.Location = new System.Drawing.Point(173, 214);
            this.btn_thread2.Name = "btn_thread2";
            this.btn_thread2.Size = new System.Drawing.Size(75, 23);
            this.btn_thread2.TabIndex = 1;
            this.btn_thread2.Text = "THREAD2";
            this.btn_thread2.UseVisualStyleBackColor = true;
            this.btn_thread2.Click += new System.EventHandler(this.btn_thread2_Click);
            // 
            // txt_thread1
            // 
            this.txt_thread1.Location = new System.Drawing.Point(39, 59);
            this.txt_thread1.Name = "txt_thread1";
            this.txt_thread1.Size = new System.Drawing.Size(100, 20);
            this.txt_thread1.TabIndex = 2;
            this.txt_thread1.TextChanged += new System.EventHandler(this.txt_thread1_TextChanged);
            // 
            // txt_thread2
            // 
            this.txt_thread2.Location = new System.Drawing.Point(172, 59);
            this.txt_thread2.Name = "txt_thread2";
            this.txt_thread2.Size = new System.Drawing.Size(100, 20);
            this.txt_thread2.TabIndex = 3;
            this.txt_thread2.TextChanged += new System.EventHandler(this.txt_thread2_TextChanged);
            // 
            // frm2_thread
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.txt_thread2);
            this.Controls.Add(this.txt_thread1);
            this.Controls.Add(this.btn_thread2);
            this.Controls.Add(this.btn_thread1);
            this.Name = "frm2_thread";
            this.Text = "frm2_thread";
            this.Load += new System.EventHandler(this.frm2_thread_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_thread1;
        private System.Windows.Forms.Button btn_thread2;
        private System.Windows.Forms.TextBox txt_thread1;
        private System.Windows.Forms.TextBox txt_thread2;
    }
}