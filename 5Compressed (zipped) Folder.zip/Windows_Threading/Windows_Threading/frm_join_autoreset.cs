﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace Windows_Threading
{
    public partial class frm_join_autoreset : Form
    {
        public frm_join_autoreset()
        {
            InitializeComponent();
        }
        public void call()
        {
            MessageBox.Show("call function");
            MessageBox.Show("call function 2");

        }

        AutoResetEvent wait = new AutoResetEvent(false);
        private void btn_jointhread_Click(object sender, EventArgs e)
        {
            Thread th = new Thread(call);
            th.Start();
            MessageBox.Show("main thread 1");
            wait.WaitOne();
            th.Join();
            MessageBox.Show("main thread 2");
        }
    }
}
