﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace Windows_Threading
{
    public partial class frm_AsyncCall : Form
    {
        public frm_AsyncCall()
        {
            InitializeComponent();
        }

        public delegate int del_sum(int n1, int n2);
    
        
        public int GetSum(int n1, int n2)
        {
            MessageBox.Show("GetSum");
            return n1 + n2;
        }
        public void callback(IAsyncResult res)
        {
            MessageBox.Show("getsum called successfully");
            int result = obj.EndInvoke(res);
            //MessageBox.Show("result:"+ res.AsyncState +"=" + result);
            lst_result.Items.Add(res.AsyncState + "=" + result);
        }
        del_sum obj;
        private void button1_Click(object sender, EventArgs e)
        {
            obj = new del_sum(GetSum);
            obj.BeginInvoke(100, 200, new AsyncCallback(callback), "100+200");//CALLBACK
            obj.BeginInvoke(300, 400, new AsyncCallback(callback), "300+400");
            MessageBox.Show("main thread");
        }
    }
}
