﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace Windows_Threading
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_new_thread_Click(object sender, EventArgs e)
        {
            ThreadStart th_del1 = new ThreadStart(call1);
            Thread th1 = new Thread(th_del1);//object creation
            th1.IsBackground = true;//run in baground 
            th1.Start();//new thread created
            
            Thread th2 = new Thread(call2);
            th2.IsBackground = true;
            th2.Start();
            MessageBox.Show("main thread");

        }
        public void call1()
        {
            MessageBox.Show("call 1 function" + Thread.CurrentThread.ManagedThreadId);
        }
        public void call2()
        {
            MessageBox.Show("call 2 function" + Thread.CurrentThread.ManagedThreadId);
        }
    }
}