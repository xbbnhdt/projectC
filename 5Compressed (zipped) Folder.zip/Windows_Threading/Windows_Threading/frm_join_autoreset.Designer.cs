﻿namespace Windows_Threading
{
    partial class frm_join_autoreset
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_jointhread = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_jointhread
            // 
            this.btn_jointhread.Location = new System.Drawing.Point(164, 121);
            this.btn_jointhread.Name = "btn_jointhread";
            this.btn_jointhread.Size = new System.Drawing.Size(214, 59);
            this.btn_jointhread.TabIndex = 0;
            this.btn_jointhread.Text = "JOIN A THREAD";
            this.btn_jointhread.UseVisualStyleBackColor = true;
            this.btn_jointhread.Click += new System.EventHandler(this.btn_jointhread_Click);
            // 
            // frm_join_autoreset
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(816, 623);
            this.Controls.Add(this.btn_jointhread);
            this.Name = "frm_join_autoreset";
            this.Text = "frm_join_autoreset";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_jointhread;
    }
}