﻿namespace Windows_assembly_assignment
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_calculatetotalwages = new System.Windows.Forms.Button();
            this.txt_workingdays = new System.Windows.Forms.TextBox();
            this.txt_dailywages = new System.Windows.Forms.TextBox();
            this.lbl_dailysalary = new System.Windows.Forms.Label();
            this.lbl_no_ofdays = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_calculatetotalwages
            // 
            this.btn_calculatetotalwages.Location = new System.Drawing.Point(182, 227);
            this.btn_calculatetotalwages.Name = "btn_calculatetotalwages";
            this.btn_calculatetotalwages.Size = new System.Drawing.Size(90, 23);
            this.btn_calculatetotalwages.TabIndex = 0;
            this.btn_calculatetotalwages.Text = "CALCULATE";
            this.btn_calculatetotalwages.UseVisualStyleBackColor = true;
            this.btn_calculatetotalwages.Click += new System.EventHandler(this.btn_calculatetotalwages_Click);
            // 
            // txt_workingdays
            // 
            this.txt_workingdays.Location = new System.Drawing.Point(140, 106);
            this.txt_workingdays.Name = "txt_workingdays";
            this.txt_workingdays.Size = new System.Drawing.Size(100, 20);
            this.txt_workingdays.TabIndex = 1;
            // 
            // txt_dailywages
            // 
            this.txt_dailywages.Location = new System.Drawing.Point(140, 67);
            this.txt_dailywages.Name = "txt_dailywages";
            this.txt_dailywages.Size = new System.Drawing.Size(100, 20);
            this.txt_dailywages.TabIndex = 2;
            // 
            // lbl_dailysalary
            // 
            this.lbl_dailysalary.AutoSize = true;
            this.lbl_dailysalary.Location = new System.Drawing.Point(35, 74);
            this.lbl_dailysalary.Name = "lbl_dailysalary";
            this.lbl_dailysalary.Size = new System.Drawing.Size(81, 13);
            this.lbl_dailysalary.TabIndex = 3;
            this.lbl_dailysalary.Text = "DAILY WAGES";
            // 
            // lbl_no_ofdays
            // 
            this.lbl_no_ofdays.AutoSize = true;
            this.lbl_no_ofdays.Location = new System.Drawing.Point(35, 113);
            this.lbl_no_ofdays.Name = "lbl_no_ofdays";
            this.lbl_no_ofdays.Size = new System.Drawing.Size(92, 13);
            this.lbl_no_ofdays.TabIndex = 4;
            this.lbl_no_ofdays.Text = "WORKING DAYS";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(299, 295);
            this.Controls.Add(this.lbl_no_ofdays);
            this.Controls.Add(this.lbl_dailysalary);
            this.Controls.Add(this.txt_dailywages);
            this.Controls.Add(this.txt_workingdays);
            this.Controls.Add(this.btn_calculatetotalwages);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_calculatetotalwages;
        private System.Windows.Forms.TextBox txt_workingdays;
        private System.Windows.Forms.TextBox txt_dailywages;
        private System.Windows.Forms.Label lbl_dailysalary;
        private System.Windows.Forms.Label lbl_no_ofdays;
    }
}

