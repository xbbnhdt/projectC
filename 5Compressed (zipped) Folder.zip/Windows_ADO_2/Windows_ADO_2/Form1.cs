﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace Windows_ADO_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_placeorder_Click(object sender, EventArgs e)
        {
            try
            {

                Order ord = new Order();
                ord.customername = txt_customername.Text;
                Item item = new Item();
                item.itemid = Convert.ToInt32(txt_itemid.Text);
                item.itemprice = Convert.ToInt32(txt_itemprice.Text);
                item.itemquantity = Convert.ToInt32(txt_itemquantity.Text);

                ord.AddItem(item);

                OrdersDAL dal = new OrdersDAL();
                dal.Addorder(ord);

                txt_orderid.Text = ord.orderid.ToString();
            }


            catch (Exception exp)
            {
                MessageBox.Show("error");
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
