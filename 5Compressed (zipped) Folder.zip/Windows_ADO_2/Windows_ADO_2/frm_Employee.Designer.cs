﻿namespace Windows_ADO_2
{
    partial class frm_Employee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_login = new System.Windows.Forms.Button();
            this.lbl_emppwd = new System.Windows.Forms.Label();
            this.lbl_emppswd = new System.Windows.Forms.Label();
            this.txt_empid = new System.Windows.Forms.TextBox();
            this.txt_emppwd = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btn_login
            // 
            this.btn_login.Location = new System.Drawing.Point(140, 162);
            this.btn_login.Name = "btn_login";
            this.btn_login.Size = new System.Drawing.Size(75, 23);
            this.btn_login.TabIndex = 0;
            this.btn_login.Text = "login";
            this.btn_login.UseVisualStyleBackColor = true;
            this.btn_login.Click += new System.EventHandler(this.btn_login_Click);
            // 
            // lbl_emppwd
            // 
            this.lbl_emppwd.AutoSize = true;
            this.lbl_emppwd.Location = new System.Drawing.Point(43, 47);
            this.lbl_emppwd.Name = "lbl_emppwd";
            this.lbl_emppwd.Size = new System.Drawing.Size(67, 13);
            this.lbl_emppwd.TabIndex = 1;
            this.lbl_emppwd.Text = "Employee ID";
            // 
            // lbl_emppswd
            // 
            this.lbl_emppswd.AutoSize = true;
            this.lbl_emppswd.Location = new System.Drawing.Point(43, 90);
            this.lbl_emppswd.Name = "lbl_emppswd";
            this.lbl_emppswd.Size = new System.Drawing.Size(53, 13);
            this.lbl_emppswd.TabIndex = 2;
            this.lbl_emppswd.Text = "Password";
            // 
            // txt_empid
            // 
            this.txt_empid.Location = new System.Drawing.Point(287, 40);
            this.txt_empid.Name = "txt_empid";
            this.txt_empid.Size = new System.Drawing.Size(100, 20);
            this.txt_empid.TabIndex = 3;
            // 
            // txt_emppwd
            // 
            this.txt_emppwd.Location = new System.Drawing.Point(289, 98);
            this.txt_emppwd.Name = "txt_emppwd";
            this.txt_emppwd.Size = new System.Drawing.Size(100, 20);
            this.txt_emppwd.TabIndex = 4;
            // 
            // frm_Employee
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(553, 409);
            this.Controls.Add(this.txt_emppwd);
            this.Controls.Add(this.txt_empid);
            this.Controls.Add(this.lbl_emppswd);
            this.Controls.Add(this.lbl_emppwd);
            this.Controls.Add(this.btn_login);
            this.Name = "frm_Employee";
            this.Text = "frm_Employee";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_login;
        private System.Windows.Forms.Label lbl_emppwd;
        private System.Windows.Forms.Label lbl_emppswd;
        private System.Windows.Forms.TextBox txt_empid;
        private System.Windows.Forms.TextBox txt_emppwd;
    }
}