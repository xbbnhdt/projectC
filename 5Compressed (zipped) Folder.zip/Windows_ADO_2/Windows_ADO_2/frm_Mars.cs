﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace Windows_ADO_2
{
    public partial class frm_Mars : Form
    {


        SqlConnection con = new
        SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        public frm_Mars()
        {
            InitializeComponent();
        }

        private void btn_mars_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand con_order = new
             SqlCommand("select * from orderstables", con);
            SqlDataReader dr_order = con_order.ExecuteReader();

            SqlCommand con_items = new SqlCommand("select 8 from orderdetails", con);
            SqlDataReader dr_items = con_items.ExecuteReader();

            DataTable dt = new DataTable();
            dt.Load(dr_order);

            dg_orders.DataSource = dt;

            con.Close();
        }
    }
}
