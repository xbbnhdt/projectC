﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;

namespace Windows_ADO_2
{
    class OrdersDAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        public void Addorder(Order ord)
        {
            //ADO.NET

            try
            {
                con.Open();
                SqlTransaction trans = con.BeginTransaction();//1

                SqlCommand con_order = new SqlCommand("insert orderstables values(@customername, getdate())", con);


                con_order.Parameters.AddWithValue("@customername", ord.customername);
                con_order.Transaction = trans;//2
                con_order.ExecuteNonQuery();
                SqlCommand con_orderid = new SqlCommand("select @@identity", con);

                con_orderid.Transaction = trans;//3
                int orderid = Convert.ToInt32(con_orderid.ExecuteScalar());
                ord.orderid = orderid;

                foreach (Item item in ord.items)
                {
                    SqlCommand con_item = new SqlCommand("insert orderdetails values(@orderid, @itemid, @itemquantity, @itemprice)", con);
                    con_item.Parameters.AddWithValue("orderid", orderid);
                    con_item.Parameters.AddWithValue("itemid", item.itemid);
                    con_item.Parameters.AddWithValue("itemquantity", item.itemquantity);
                    con_item.Parameters.AddWithValue("@itemprice", item.itemprice);
                    con_item.Transaction = trans;//4
                    con_item.ExecuteNonQuery();
                }


                //System.Windows.Forms.MessageBox.Show("wait");

                trans.Commit();//5
            }
            finally
            {
                if (con.State == System.Data.ConnectionState.Open)
                {
                    con.Close();
                }
            }    
            

        }

    }
}
