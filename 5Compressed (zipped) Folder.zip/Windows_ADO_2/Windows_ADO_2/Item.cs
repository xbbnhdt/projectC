﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Windows_ADO_2
{
    class Item
    {
        public int orderid { set; get; }
        public int itemid { set; get; }
        public int itemquantity { set; get; }
        public int itemprice { set; get; }

            

    }
}
