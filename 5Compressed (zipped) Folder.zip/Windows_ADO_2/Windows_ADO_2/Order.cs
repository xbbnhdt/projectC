﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Windows_ADO_2
{
    class Order
    {

        public int orderid { set; get; }
        public string customername { set; get; }
    
            public DateTime orderdate { set; get; }

            public List<Item> items = new List<Item>();
            public void AddItem(Item item)
            {

                items.Add(item);
            
            }


    }
}
