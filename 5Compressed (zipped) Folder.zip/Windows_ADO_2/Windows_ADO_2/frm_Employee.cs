﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;


namespace Windows_ADO_2
{
    public partial class frm_Employee : Form
    {

        SqlConnection con = new
      SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        public frm_Employee()
        {
            InitializeComponent();
        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            Employee obj = new Employee();
            obj.employeeid = Convert.ToInt32(txt_empid.Text);
            obj.employeepasword = txt_emppwd.Text;
            EmployeeDAL dal = new EmployeeDAL();
            bool status = dal.Login(obj);
            if (status)
            {

                MessageBox.Show("valid user");
            }

            else
            {
                MessageBox.Show("invalid user");
            }
        }
    }
}
