﻿namespace Windows_ADO_2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_placeorder = new System.Windows.Forms.Button();
            this.lbl_orderid = new System.Windows.Forms.Label();
            this.lbl_customername = new System.Windows.Forms.Label();
            this.lbl_itemid = new System.Windows.Forms.Label();
            this.lbl_itemquantity = new System.Windows.Forms.Label();
            this.lbl_itemprice = new System.Windows.Forms.Label();
            this.txt_orderid = new System.Windows.Forms.TextBox();
            this.txt_customername = new System.Windows.Forms.TextBox();
            this.txt_itemid = new System.Windows.Forms.TextBox();
            this.txt_itemquantity = new System.Windows.Forms.TextBox();
            this.txt_itemprice = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btn_placeorder
            // 
            this.btn_placeorder.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_placeorder.ForeColor = System.Drawing.Color.Blue;
            this.btn_placeorder.Location = new System.Drawing.Point(12, 221);
            this.btn_placeorder.Name = "btn_placeorder";
            this.btn_placeorder.Size = new System.Drawing.Size(152, 23);
            this.btn_placeorder.TabIndex = 0;
            this.btn_placeorder.Text = "PLACE ORDER";
            this.btn_placeorder.UseVisualStyleBackColor = true;
            this.btn_placeorder.Click += new System.EventHandler(this.btn_placeorder_Click);
            // 
            // lbl_orderid
            // 
            this.lbl_orderid.AutoSize = true;
            this.lbl_orderid.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_orderid.ForeColor = System.Drawing.Color.Blue;
            this.lbl_orderid.Location = new System.Drawing.Point(26, 33);
            this.lbl_orderid.Name = "lbl_orderid";
            this.lbl_orderid.Size = new System.Drawing.Size(70, 16);
            this.lbl_orderid.TabIndex = 1;
            this.lbl_orderid.Text = "ORDER ID";
            // 
            // lbl_customername
            // 
            this.lbl_customername.AutoSize = true;
            this.lbl_customername.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_customername.ForeColor = System.Drawing.Color.Blue;
            this.lbl_customername.Location = new System.Drawing.Point(26, 72);
            this.lbl_customername.Name = "lbl_customername";
            this.lbl_customername.Size = new System.Drawing.Size(122, 16);
            this.lbl_customername.TabIndex = 2;
            this.lbl_customername.Text = "CUSTOMER NAME";
            // 
            // lbl_itemid
            // 
            this.lbl_itemid.AutoSize = true;
            this.lbl_itemid.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_itemid.ForeColor = System.Drawing.Color.Blue;
            this.lbl_itemid.Location = new System.Drawing.Point(26, 105);
            this.lbl_itemid.Name = "lbl_itemid";
            this.lbl_itemid.Size = new System.Drawing.Size(56, 16);
            this.lbl_itemid.TabIndex = 3;
            this.lbl_itemid.Text = "ITEM ID";
            // 
            // lbl_itemquantity
            // 
            this.lbl_itemquantity.AutoSize = true;
            this.lbl_itemquantity.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_itemquantity.ForeColor = System.Drawing.Color.Blue;
            this.lbl_itemquantity.Location = new System.Drawing.Point(26, 141);
            this.lbl_itemquantity.Name = "lbl_itemquantity";
            this.lbl_itemquantity.Size = new System.Drawing.Size(108, 16);
            this.lbl_itemquantity.TabIndex = 4;
            this.lbl_itemquantity.Text = "ITEM QUANTITY";
            // 
            // lbl_itemprice
            // 
            this.lbl_itemprice.AutoSize = true;
            this.lbl_itemprice.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_itemprice.ForeColor = System.Drawing.Color.Blue;
            this.lbl_itemprice.Location = new System.Drawing.Point(26, 172);
            this.lbl_itemprice.Name = "lbl_itemprice";
            this.lbl_itemprice.Size = new System.Drawing.Size(82, 16);
            this.lbl_itemprice.TabIndex = 5;
            this.lbl_itemprice.Text = "ITEM PRICE";
            // 
            // txt_orderid
            // 
            this.txt_orderid.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_orderid.Location = new System.Drawing.Point(188, 26);
            this.txt_orderid.Name = "txt_orderid";
            this.txt_orderid.Size = new System.Drawing.Size(100, 22);
            this.txt_orderid.TabIndex = 6;
            // 
            // txt_customername
            // 
            this.txt_customername.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_customername.Location = new System.Drawing.Point(188, 65);
            this.txt_customername.Name = "txt_customername";
            this.txt_customername.Size = new System.Drawing.Size(100, 22);
            this.txt_customername.TabIndex = 7;
            // 
            // txt_itemid
            // 
            this.txt_itemid.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_itemid.Location = new System.Drawing.Point(188, 98);
            this.txt_itemid.Name = "txt_itemid";
            this.txt_itemid.Size = new System.Drawing.Size(100, 22);
            this.txt_itemid.TabIndex = 8;
            // 
            // txt_itemquantity
            // 
            this.txt_itemquantity.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_itemquantity.Location = new System.Drawing.Point(188, 134);
            this.txt_itemquantity.Name = "txt_itemquantity";
            this.txt_itemquantity.Size = new System.Drawing.Size(100, 22);
            this.txt_itemquantity.TabIndex = 9;
            // 
            // txt_itemprice
            // 
            this.txt_itemprice.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_itemprice.Location = new System.Drawing.Point(188, 172);
            this.txt_itemprice.Name = "txt_itemprice";
            this.txt_itemprice.Size = new System.Drawing.Size(100, 22);
            this.txt_itemprice.TabIndex = 10;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(327, 283);
            this.Controls.Add(this.txt_itemprice);
            this.Controls.Add(this.txt_itemquantity);
            this.Controls.Add(this.txt_itemid);
            this.Controls.Add(this.txt_customername);
            this.Controls.Add(this.txt_orderid);
            this.Controls.Add(this.lbl_itemprice);
            this.Controls.Add(this.lbl_itemquantity);
            this.Controls.Add(this.lbl_itemid);
            this.Controls.Add(this.lbl_customername);
            this.Controls.Add(this.lbl_orderid);
            this.Controls.Add(this.btn_placeorder);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_placeorder;
        private System.Windows.Forms.Label lbl_orderid;
        private System.Windows.Forms.Label lbl_customername;
        private System.Windows.Forms.Label lbl_itemid;
        private System.Windows.Forms.Label lbl_itemquantity;
        private System.Windows.Forms.Label lbl_itemprice;
        private System.Windows.Forms.TextBox txt_orderid;
        private System.Windows.Forms.TextBox txt_customername;
        private System.Windows.Forms.TextBox txt_itemid;
        private System.Windows.Forms.TextBox txt_itemquantity;
        private System.Windows.Forms.TextBox txt_itemprice;
    }
}

