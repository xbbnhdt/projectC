﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;

namespace WCF_Service
{
    [ServiceContract]
    interface IService
    {
        [OperationContract]
        int GetSalary(int days, int Sal_Per_Day);
    }
       
}
