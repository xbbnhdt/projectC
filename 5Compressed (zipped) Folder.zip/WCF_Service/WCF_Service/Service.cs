﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WCF_Service
{
    class Service : IService
    {
        public int GetSalary(int days, int Sal_Per_Day)
        {
            return days * Sal_Per_Day;
        }
    }
}
