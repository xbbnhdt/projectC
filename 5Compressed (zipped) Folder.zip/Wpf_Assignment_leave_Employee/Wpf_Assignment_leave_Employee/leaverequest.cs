﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Wpf_Assignment_leave_Employee
{
    class leaverequestinput
    {
        public int leaveid { get; set; }
        public int employeeid { get; set; }
        public DateTime leavereqdate { get; set; }
        public DateTime leavedate { get; set; }
        public int noofdays { get; set; }
        public string leavetype { get; set; }
        public string reason { get; set; }
        public string leavestatus { get; set; }
        public int managerid { get; set; }
    }
}


