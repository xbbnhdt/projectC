﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Wpf_Assignment_leave_Employee
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btn_login_Click(object sender, RoutedEventArgs e)
        {

            employeedal dal = new employeedal();
            employee emp = new employee();
            emp.employeeid = Convert.ToInt32(txt_username.Text);
            emp.employeepassword = txt_password.Password;
            if (dal.login(emp))
            {
                MessageBox.Show("Valid Employee");
                App.Current.Properties.Add("empid", txt_username.Text);
                Home ob = new Home();
                ob.Show();

                this.Close();

            }
            else
            {
                MessageBox.Show("Invalid Customer");
            }

        }
    }
}


