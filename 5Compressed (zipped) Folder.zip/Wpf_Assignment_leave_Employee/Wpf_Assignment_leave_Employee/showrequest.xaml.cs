﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Wpf_Assignment_leave_Employee
{
    /// <summary>
    /// Interaction logic for showrequest.xaml
    /// </summary>
    public partial class showrequest : Window
    {
        public showrequest()
        {
            InitializeComponent();
        }

        private void btn_showmyleave_Click(object sender, RoutedEventArgs e)
        {
            leavereqdal dal = new leavereqdal();
            int employeeid = Convert.ToInt32(App.Current.Properties["empid"]);
            dg_showleaves.ItemsSource = dal.showleave(employeeid);

        }
    }
}
