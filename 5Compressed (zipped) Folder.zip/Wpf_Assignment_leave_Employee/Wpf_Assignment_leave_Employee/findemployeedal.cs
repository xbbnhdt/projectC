﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Data.SqlClient;

namespace Wpf_Assignment_leave_Employee
{
    class findemployeedal
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);

        public employee GetEmployee(int employeeid)
        {

            employee p = new employee();
            SqlCommand com_findemployee = new SqlCommand("select * from  employee where employeeid=@empid", con);
            com_findemployee.Parameters.AddWithValue("@empid", employeeid);
            con.Open();
            SqlDataReader dr = com_findemployee.ExecuteReader();
            if (dr.Read())
            {
                p.employeeid = dr.GetInt32(0);
                p.employeename = dr.GetString(1);
                p.employeeexp = dr.GetInt32(2);
                p.employeedept = dr.GetString(4);
                p.employeedesignation = dr.GetString(5);
            }
            con.Close();
            return p;



        }

    }
}
