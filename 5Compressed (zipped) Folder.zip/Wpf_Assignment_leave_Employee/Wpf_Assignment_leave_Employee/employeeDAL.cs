﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Data.SqlClient;

namespace Wpf_Assignment_leave_Employee
{
    class employeedal
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        public List<employee> showemployee()
        {
            List<employee> showemployeelist = new List<employee>();
            SqlCommand com_showemployee = new SqlCommand("Select * from employee", con);

            con.Open();
            SqlDataReader dr = com_showemployee.ExecuteReader();
            while (dr.Read())
            {
                employee l = new employee();
                l.employeeid = dr.GetInt32(0);
                l.employeename = dr.GetString(1);
                l.employeeexp = dr.GetInt32(2);
                l.employeedept = dr.GetString(4);
                l.employeedesignation = dr.GetString(5);

                showemployeelist.Add(l);
            }
            con.Close();
            return showemployeelist;
        }
    }
}


       