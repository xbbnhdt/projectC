﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Wpf_Assignment_leave_Employee
{
    class employee
    {
        public int employeeid { get; set; }
        public string employeename { get; set; }
        public int employeeexp { get; set; }
        public string employeepassword { get; set; }
        public string employeedept { get; set; }
        public string employeedesignation { get; set; }

    }
}