﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Wpf_Assignment_Addemployee
{
    /// <summary>
    /// Interaction logic for Home.xaml
    /// </summary>
    public partial class Home : Window
    {
        public Home()
        {
            InitializeComponent();
        }

        private void btn_leaverequest_Click(object sender, RoutedEventArgs e)
        {
            win_leaverequest lea = new win_leaverequest();
            lea.Show();
        }

        private void btn_showrequest_Click(object sender, RoutedEventArgs e)
        {
            showrequest obj = new showrequest();
            obj.Show();
        }

        private void btn_showemployee_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btn_findemployee_Click(object sender, RoutedEventArgs e)
        {
            FindEmployee obj = new FindEmployee();
            obj.Show();
        }
    }
}
