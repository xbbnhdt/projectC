﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Data.SqlClient;

namespace Wpf_Assignment_leave_Employee
{
    class leavereqdal
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        public bool Getleavereq(leaverequestinput l)
        {
            con.Open();
            SqlCommand com_leaverequest = new SqlCommand("insert leaverequest values(@empid,getdate(),@leavedate,@noofdays,@leavetype,@reason,@leavestatus,@managerid)", con);

            com_leaverequest.Parameters.AddWithValue("@empid", l.employeeid);

            com_leaverequest.Parameters.AddWithValue("@leavedate", l.leavedate);
            com_leaverequest.Parameters.AddWithValue("@noofdays", l.noofdays);
            com_leaverequest.Parameters.AddWithValue("@leavetype", l.leavetype);
            com_leaverequest.Parameters.AddWithValue("@reason", l.reason);
            com_leaverequest.Parameters.AddWithValue("@leavestatus", l.leavestatus);
            com_leaverequest.Parameters.AddWithValue("@managerid", l.managerid);
            com_leaverequest.ExecuteNonQuery();

            SqlCommand com_empid = new SqlCommand("Select @@identity", con);
            int leaveid = Convert.ToInt32(com_leaverequest.ExecuteScalar());
            l.leaveid = leaveid;
            con.Close();
            return true;
        }
        public List<leaverequestinput> showleave(int employeeid)
        {
            List<leaverequestinput> showleavelist = new List<leaverequestinput>();
            SqlCommand com_showleaves = new SqlCommand("Select * from leaverequest where employeeid=@empid", con);
            com_showleaves.Parameters.AddWithValue("@empid", employeeid);
            con.Open();
            SqlDataReader dr = com_showleaves.ExecuteReader();
            while (dr.Read())
            {
                leaverequestinput l = new leaverequestinput();
                l.leaveid = dr.GetInt32(0);
                l.employeeid = dr.GetInt32(1);
                l.leavereqdate = dr.GetDateTime(2);
                l.leavedate = dr.GetDateTime(3);
                l.noofdays = dr.GetInt32(4);
                l.leavetype = dr.GetString(5);
                l.reason = dr.GetString(6);
                l.leavestatus = dr.GetString(7);
                l.managerid = dr.GetInt32(8);

                showleavelist.Add(l);
            }
            con.Close();
            return showleavelist;










        }
    }
}
