﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Wpf_Assignment_leave_Employee
{
    /// <summary>
    /// Interaction logic for win_leaverequest.xaml
    /// </summary>
    public partial class win_leaverequest : Window
    {
        public win_leaverequest()
        {
            InitializeComponent();
        }

        private void btn_createleaverequest_Click(object sender, RoutedEventArgs e)
        {
            leaverequestinput p = new leaverequestinput();
            leavereqdal dal = new leavereqdal();

            p.employeeid = Convert.ToInt32(txt_empid.Text);

            p.leavedate = Convert.ToDateTime(txt_leavedate.Text);
            p.noofdays = Convert.ToInt32(txt_noofdays.Text);
            p.leavetype = txt_leavetype.Text;
            p.reason = txt_leavereason.Text;
            p.leavestatus = txt_leavestatus.Text;


            dal.Getleavereq(p);
            MessageBox.Show("Leave is requested Successfully" + p.leaveid);


        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            txt_empid.Text = App.Current.Properties["empid"].ToString();
        }
    }
}

