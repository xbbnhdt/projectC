﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Wpf_Assignment_leave_Employee
{
    /// <summary>
    /// Interaction logic for FindEmployee.xaml
    /// </summary>
    public partial class FindEmployee : Window
    {
        public FindEmployee()
        {
            InitializeComponent();
        }

       

        private void btn_findemployee_Click_1(object sender, RoutedEventArgs e)
        {
            findemployeedal dal = new findemployeedal();
            stp_findemployee.DataContext = dal.GetEmployee(Convert.ToInt32(txt_empid.Text));
        }
    }
}
