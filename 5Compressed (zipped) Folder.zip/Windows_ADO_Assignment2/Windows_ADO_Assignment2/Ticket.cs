﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Windows_ADO_Assignment2
{
    class Ticket
    {
        public int TicketNumber {set;get;}
          public string MovieName {set;get;}
            public DateTime MovieDate {set;get;}
             public DateTime MovieTiming {set;get;}
           public int NoOfTickets {set;get;}
           public int TransactionID {set;get;}
           public DateTime TicketPurchaseDate { set; get; } 

    }
}
