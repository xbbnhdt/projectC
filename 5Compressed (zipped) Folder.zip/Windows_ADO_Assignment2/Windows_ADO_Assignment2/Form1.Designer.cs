﻿namespace Windows_ADO_Assignment2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_bookticket = new System.Windows.Forms.Button();
            this.lbl_moviename = new System.Windows.Forms.Label();
            this.lbl_moviedate = new System.Windows.Forms.Label();
            this.lbl_movietiming = new System.Windows.Forms.Label();
            this.lbl_nooftickets = new System.Windows.Forms.Label();
            this.lbl_totalamount = new System.Windows.Forms.Label();
            this.lbl_transactionid = new System.Windows.Forms.Label();
            this.lbl_accountnumber = new System.Windows.Forms.Label();
            this.txt_moviename = new System.Windows.Forms.TextBox();
            this.txt_movietiming = new System.Windows.Forms.TextBox();
            this.txt_totalamount = new System.Windows.Forms.TextBox();
            this.txt_moviedate = new System.Windows.Forms.TextBox();
            this.txt_nooftickets = new System.Windows.Forms.TextBox();
            this.txt_accountnumber = new System.Windows.Forms.TextBox();
            this.txt_transactionid = new System.Windows.Forms.TextBox();
            this.txt_ticketnumber = new System.Windows.Forms.TextBox();
            this.lbl_ticketnumber = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_bookticket
            // 
            this.btn_bookticket.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_bookticket.ForeColor = System.Drawing.Color.Blue;
            this.btn_bookticket.Location = new System.Drawing.Point(180, 281);
            this.btn_bookticket.Name = "btn_bookticket";
            this.btn_bookticket.Size = new System.Drawing.Size(138, 38);
            this.btn_bookticket.TabIndex = 0;
            this.btn_bookticket.Text = "BOOK NOW";
            this.btn_bookticket.UseVisualStyleBackColor = true;
            this.btn_bookticket.Click += new System.EventHandler(this.btn_bookticket_Click);
            // 
            // lbl_moviename
            // 
            this.lbl_moviename.AutoSize = true;
            this.lbl_moviename.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_moviename.ForeColor = System.Drawing.Color.Blue;
            this.lbl_moviename.Location = new System.Drawing.Point(58, 59);
            this.lbl_moviename.Name = "lbl_moviename";
            this.lbl_moviename.Size = new System.Drawing.Size(111, 18);
            this.lbl_moviename.TabIndex = 1;
            this.lbl_moviename.Text = "MOVIE NAME :";
            // 
            // lbl_moviedate
            // 
            this.lbl_moviedate.AutoSize = true;
            this.lbl_moviedate.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_moviedate.ForeColor = System.Drawing.Color.Blue;
            this.lbl_moviedate.Location = new System.Drawing.Point(354, 59);
            this.lbl_moviedate.Name = "lbl_moviedate";
            this.lbl_moviedate.Size = new System.Drawing.Size(107, 18);
            this.lbl_moviedate.TabIndex = 2;
            this.lbl_moviedate.Text = "MOVIE DATE :";
            // 
            // lbl_movietiming
            // 
            this.lbl_movietiming.AutoSize = true;
            this.lbl_movietiming.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_movietiming.ForeColor = System.Drawing.Color.Blue;
            this.lbl_movietiming.Location = new System.Drawing.Point(58, 137);
            this.lbl_movietiming.Name = "lbl_movietiming";
            this.lbl_movietiming.Size = new System.Drawing.Size(122, 18);
            this.lbl_movietiming.TabIndex = 3;
            this.lbl_movietiming.Text = "MOVIE TIMING :";
            // 
            // lbl_nooftickets
            // 
            this.lbl_nooftickets.AutoSize = true;
            this.lbl_nooftickets.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_nooftickets.ForeColor = System.Drawing.Color.Blue;
            this.lbl_nooftickets.Location = new System.Drawing.Point(354, 134);
            this.lbl_nooftickets.Name = "lbl_nooftickets";
            this.lbl_nooftickets.Size = new System.Drawing.Size(138, 18);
            this.lbl_nooftickets.TabIndex = 4;
            this.lbl_nooftickets.Text = "NO. OF TICKETS :";
            // 
            // lbl_totalamount
            // 
            this.lbl_totalamount.AutoSize = true;
            this.lbl_totalamount.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_totalamount.ForeColor = System.Drawing.Color.Blue;
            this.lbl_totalamount.Location = new System.Drawing.Point(58, 218);
            this.lbl_totalamount.Name = "lbl_totalamount";
            this.lbl_totalamount.Size = new System.Drawing.Size(134, 18);
            this.lbl_totalamount.TabIndex = 5;
            this.lbl_totalamount.Text = "TOTAL AMOUNT :";
            // 
            // lbl_transactionid
            // 
            this.lbl_transactionid.AutoSize = true;
            this.lbl_transactionid.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_transactionid.ForeColor = System.Drawing.Color.Blue;
            this.lbl_transactionid.Location = new System.Drawing.Point(58, 373);
            this.lbl_transactionid.Name = "lbl_transactionid";
            this.lbl_transactionid.Size = new System.Drawing.Size(205, 18);
            this.lbl_transactionid.TabIndex = 6;
            this.lbl_transactionid.Text = "YOUR TRANSACTION ID IS:";
            // 
            // lbl_accountnumber
            // 
            this.lbl_accountnumber.AutoSize = true;
            this.lbl_accountnumber.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_accountnumber.ForeColor = System.Drawing.Color.Blue;
            this.lbl_accountnumber.Location = new System.Drawing.Point(354, 218);
            this.lbl_accountnumber.Name = "lbl_accountnumber";
            this.lbl_accountnumber.Size = new System.Drawing.Size(162, 18);
            this.lbl_accountnumber.TabIndex = 7;
            this.lbl_accountnumber.Text = "ACCOUNT NUMBER :";
            // 
            // txt_moviename
            // 
            this.txt_moviename.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_moviename.Location = new System.Drawing.Point(194, 54);
            this.txt_moviename.Name = "txt_moviename";
            this.txt_moviename.Size = new System.Drawing.Size(100, 22);
            this.txt_moviename.TabIndex = 8;
            // 
            // txt_movietiming
            // 
            this.txt_movietiming.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_movietiming.Location = new System.Drawing.Point(193, 131);
            this.txt_movietiming.Name = "txt_movietiming";
            this.txt_movietiming.Size = new System.Drawing.Size(100, 22);
            this.txt_movietiming.TabIndex = 9;
            // 
            // txt_totalamount
            // 
            this.txt_totalamount.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_totalamount.Location = new System.Drawing.Point(193, 213);
            this.txt_totalamount.Name = "txt_totalamount";
            this.txt_totalamount.Size = new System.Drawing.Size(100, 22);
            this.txt_totalamount.TabIndex = 10;
            // 
            // txt_moviedate
            // 
            this.txt_moviedate.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_moviedate.Location = new System.Drawing.Point(511, 61);
            this.txt_moviedate.Name = "txt_moviedate";
            this.txt_moviedate.Size = new System.Drawing.Size(100, 22);
            this.txt_moviedate.TabIndex = 11;
            // 
            // txt_nooftickets
            // 
            this.txt_nooftickets.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_nooftickets.Location = new System.Drawing.Point(513, 125);
            this.txt_nooftickets.Name = "txt_nooftickets";
            this.txt_nooftickets.Size = new System.Drawing.Size(100, 22);
            this.txt_nooftickets.TabIndex = 12;
            // 
            // txt_accountnumber
            // 
            this.txt_accountnumber.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_accountnumber.Location = new System.Drawing.Point(513, 211);
            this.txt_accountnumber.Name = "txt_accountnumber";
            this.txt_accountnumber.Size = new System.Drawing.Size(100, 22);
            this.txt_accountnumber.TabIndex = 13;
            // 
            // txt_transactionid
            // 
            this.txt_transactionid.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_transactionid.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.txt_transactionid.Location = new System.Drawing.Point(284, 371);
            this.txt_transactionid.Name = "txt_transactionid";
            this.txt_transactionid.Size = new System.Drawing.Size(262, 22);
            this.txt_transactionid.TabIndex = 14;
            // 
            // txt_ticketnumber
            // 
            this.txt_ticketnumber.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_ticketnumber.Location = new System.Drawing.Point(284, 412);
            this.txt_ticketnumber.Name = "txt_ticketnumber";
            this.txt_ticketnumber.Size = new System.Drawing.Size(262, 22);
            this.txt_ticketnumber.TabIndex = 15;
            // 
            // lbl_ticketnumber
            // 
            this.lbl_ticketnumber.AutoSize = true;
            this.lbl_ticketnumber.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ticketnumber.ForeColor = System.Drawing.Color.Blue;
            this.lbl_ticketnumber.Location = new System.Drawing.Point(62, 411);
            this.lbl_ticketnumber.Name = "lbl_ticketnumber";
            this.lbl_ticketnumber.Size = new System.Drawing.Size(191, 18);
            this.lbl_ticketnumber.TabIndex = 16;
            this.lbl_ticketnumber.Text = "YOUR TICKET NUMBER :";
            this.lbl_ticketnumber.Click += new System.EventHandler(this.label1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(685, 453);
            this.Controls.Add(this.lbl_ticketnumber);
            this.Controls.Add(this.txt_ticketnumber);
            this.Controls.Add(this.txt_transactionid);
            this.Controls.Add(this.txt_accountnumber);
            this.Controls.Add(this.txt_nooftickets);
            this.Controls.Add(this.txt_moviedate);
            this.Controls.Add(this.txt_totalamount);
            this.Controls.Add(this.txt_movietiming);
            this.Controls.Add(this.txt_moviename);
            this.Controls.Add(this.lbl_accountnumber);
            this.Controls.Add(this.lbl_transactionid);
            this.Controls.Add(this.lbl_totalamount);
            this.Controls.Add(this.lbl_nooftickets);
            this.Controls.Add(this.lbl_movietiming);
            this.Controls.Add(this.lbl_moviedate);
            this.Controls.Add(this.lbl_moviename);
            this.Controls.Add(this.btn_bookticket);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_bookticket;
        private System.Windows.Forms.Label lbl_moviename;
        private System.Windows.Forms.Label lbl_moviedate;
        private System.Windows.Forms.Label lbl_movietiming;
        private System.Windows.Forms.Label lbl_nooftickets;
        private System.Windows.Forms.Label lbl_totalamount;
        private System.Windows.Forms.Label lbl_transactionid;
        private System.Windows.Forms.Label lbl_accountnumber;
        private System.Windows.Forms.TextBox txt_moviename;
        private System.Windows.Forms.TextBox txt_movietiming;
        private System.Windows.Forms.TextBox txt_totalamount;
        private System.Windows.Forms.TextBox txt_moviedate;
        private System.Windows.Forms.TextBox txt_nooftickets;
        private System.Windows.Forms.TextBox txt_accountnumber;
        private System.Windows.Forms.TextBox txt_transactionid;
        private System.Windows.Forms.TextBox txt_ticketnumber;
        private System.Windows.Forms.Label lbl_ticketnumber;
    }
}

