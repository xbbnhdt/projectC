﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Windows_ADO_Assignment2
{
    class Bank
    {
        public int TransactionID {set;get;}
        public int AccountNumber {set;get;}
        public int Amount {set;get;}
        public int TransactionDate { set; get; }
    

    }
}
