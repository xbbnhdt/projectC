﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace Windows_ADO_Assignment2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_bookticket_Click(object sender, EventArgs e)
        {
            Ticket ord = new Ticket();
            ord.MovieName = txt_moviename.Text;
            ord.MovieDate = Convert.ToDateTime(txt_movietiming.Text);
            ord.MovieTiming = Convert.ToDateTime( txt_movietiming.Text);
            ord.NoOfTickets = Convert.ToInt32(txt_nooftickets.Text);

            Bank obj = new Bank();
            obj.AccountNumber = Convert.ToInt32(txt_accountnumber .Text);
            obj.Amount = Convert.ToInt32(txt_totalamount.Text);
           

           
            TicketDAL dal = new TicketDAL();
            dal.addticket(ord,obj);

            txt_transactionid.Text = obj.TransactionID.ToString();
            txt_ticketnumber.Text = ord.TicketNumber.ToString();

          


        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
