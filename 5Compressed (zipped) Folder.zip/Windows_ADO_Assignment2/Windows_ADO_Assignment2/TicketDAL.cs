﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;

namespace Windows_ADO_Assignment2
{
    class TicketDAL
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        public void addticket(Ticket ord, Bank obj)
        {

            con.Open();
            SqlTransaction trans = con.BeginTransaction();
            SqlCommand con_bank = new
           SqlCommand("insert bank values( @AccountNumber, @Amount, getdate())", con);
            con_bank.Parameters.AddWithValue("@AccountNumber", obj.AccountNumber);
            con_bank.Parameters.AddWithValue("@Amount", obj.Amount);
            con_bank.Transaction = trans;
            con_bank.ExecuteNonQuery();

            SqlCommand con_transactionnumber = new SqlCommand("select @@identity", con);

            con_transactionnumber.Transaction = trans;
            int transactionid = Convert.ToInt32(con_transactionnumber.ExecuteScalar());
            obj.TransactionID = transactionid;
            SqlCommand con_ticket = new 
            SqlCommand("insert ticket values(@TransactionID, @MovieName, @MovieDate, @MovieTiming, @NoOfTickets, getdate())" ,con);
            con_ticket.Parameters.AddWithValue("@TransactionID",transactionid);
            con_ticket.Parameters.AddWithValue("@MovieName",ord.MovieName);
            con_ticket.Parameters.AddWithValue("@MovieDate", ord.MovieDate);
            con_ticket.Parameters.AddWithValue("@MovieTiming", ord.MovieTiming);
            con_ticket.Parameters.AddWithValue("@NoOfTickets", ord.NoOfTickets);
            con_ticket.Transaction = trans;
            con_ticket.ExecuteNonQuery();

           

            SqlCommand con_ticketnumber = new SqlCommand("select @@identity", con);
            
            con_ticketnumber.Transaction = trans;
            int ticketnumber = Convert.ToInt32(con_ticketnumber.ExecuteScalar());
            ord.TicketNumber = ticketnumber;

            
       
            trans.Commit();        
            con.Close();
        
        
        }

    }
}
