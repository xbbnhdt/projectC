﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace Windows_ADO_1
{
    public partial class Form1 : Form
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_reset_Click(object sender, EventArgs e)
        {
            txt_empid.Text = "";
            txt_empage.Text = "";
            cmb_empcity.Text = "";
            txt_empname.Text = "";
            txt_emppassword.Text = "";
        }
        private void btn_addemp_Click(object sender, EventArgs e)
        {
            win_ado1 obj = new win_ado1();
            obj.employeename = txt_empname.Text;
            obj.employeecity = cmb_empcity.Text;
            obj.employeeage = Convert.ToInt32(txt_empage.Text);
            obj.employeepassword = txt_emppassword.Text;
            Employeesdal dal = new Employeesdal();
            dal.addemployee(obj);
            MessageBox.Show("employee added success" +
            obj.employeeid);

        }



      

        private void txt_empname_TextChanged(object sender, EventArgs e)
        {

        }

        private void btn_findemp_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand con_find_emp = new SqlCommand("Select * from employees where employeeid = @empid", con);
            con_find_emp.Parameters.AddWithValue("@empid", txt_empid.Text);
            SqlDataReader dr = con_find_emp.ExecuteReader();
            if (dr.Read())
            {
                txt_empid.Text = dr.GetInt32(0).ToString();
                txt_empname.Text = dr.GetString(1);
                cmb_empcity.Text = dr.GetString(2);
                txt_empage.Text = dr.GetInt32(3).ToString();
                txt_emppassword.Text=dr.GetString(4);


            }
            else
            {
                MessageBox.Show("employee not found");
            }
            con.Close();
        }

        private void btn_updateemp_Click(object sender, EventArgs e)
        {
            con.Open();

            SqlCommand con_update_emp = new SqlCommand("update employees set employeename=@empname, employeecity = @empcity where employeeid = @empid", con);
            con_update_emp.Parameters.AddWithValue("@empname", txt_empname.Text);
            con_update_emp.Parameters.AddWithValue("@empcity", cmb_empcity.Text);
            con_update_emp.Parameters.AddWithValue("@empid", txt_empid.Text);
            int rowsaffected = con_update_emp.ExecuteNonQuery();
            
            con.Close();

            if (rowsaffected > 0)
            {
                MessageBox.Show("employee updated");
            }
            else
            {
                MessageBox.Show("employee not shown");
            }
    }

        private void cmb_empcity_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand con_cities = new SqlCommand("select cityname from cities", con);
            SqlDataReader dr = con_cities.ExecuteReader();
            while(dr.Read())
            {
                cmb_empcity.Items.Add(dr.GetString(0));

            }


            con.Close();
        }
}}
