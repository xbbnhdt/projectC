﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;

namespace Windows_ADO_1
{
    class Employeesdal
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        public bool addemployee(win_ado1 obj)
        {
           
            con.Open();
            SqlCommand con_emp_insert = new SqlCommand("insert employees values(@empname,@empcity,@empage,@empswd)", con);

            con_emp_insert.Parameters.AddWithValue("@empname", obj.employeename);
            con_emp_insert.Parameters.AddWithValue("@empcity", obj.employeecity);
            con_emp_insert.Parameters.AddWithValue("@empage", obj.employeeage);
            con_emp_insert.Parameters.AddWithValue("@empswd", obj.employeepassword);
            con_emp_insert.ExecuteNonQuery();
            SqlCommand con_employeeid = new SqlCommand("select @@identity", con);
            int empid = Convert.ToInt32(con_employeeid.ExecuteScalar());
            obj.employeeid = empid;
            con.Close();
            return true;


        }
    }
}
