﻿namespace Windows_ADO_1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_addemp = new System.Windows.Forms.Button();
            this.lbl_empid = new System.Windows.Forms.Label();
            this.lbl_empname = new System.Windows.Forms.Label();
            this.lbl_empcity = new System.Windows.Forms.Label();
            this.lbl_empage = new System.Windows.Forms.Label();
            this.lbl_emppassword = new System.Windows.Forms.Label();
            this.txt_empid = new System.Windows.Forms.TextBox();
            this.txt_empname = new System.Windows.Forms.TextBox();
            this.txt_empage = new System.Windows.Forms.TextBox();
            this.txt_emppassword = new System.Windows.Forms.TextBox();
            this.btn_reset = new System.Windows.Forms.Button();
            this.btn_findemp = new System.Windows.Forms.Button();
            this.btn_updateemp = new System.Windows.Forms.Button();
            this.cmb_empcity = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // btn_addemp
            // 
            this.btn_addemp.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_addemp.ForeColor = System.Drawing.Color.Red;
            this.btn_addemp.Location = new System.Drawing.Point(12, 283);
            this.btn_addemp.Name = "btn_addemp";
            this.btn_addemp.Size = new System.Drawing.Size(145, 61);
            this.btn_addemp.TabIndex = 0;
            this.btn_addemp.Text = "ADD EMPLOYEE";
            this.btn_addemp.UseVisualStyleBackColor = true;
            this.btn_addemp.Click += new System.EventHandler(this.btn_addemp_Click);
            // 
            // lbl_empid
            // 
            this.lbl_empid.AutoSize = true;
            this.lbl_empid.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_empid.ForeColor = System.Drawing.Color.Blue;
            this.lbl_empid.Location = new System.Drawing.Point(49, 50);
            this.lbl_empid.Name = "lbl_empid";
            this.lbl_empid.Size = new System.Drawing.Size(144, 18);
            this.lbl_empid.TabIndex = 1;
            this.lbl_empid.Text = "EMPLOYEE ID :";
            // 
            // lbl_empname
            // 
            this.lbl_empname.AutoSize = true;
            this.lbl_empname.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_empname.ForeColor = System.Drawing.Color.Blue;
            this.lbl_empname.Location = new System.Drawing.Point(46, 92);
            this.lbl_empname.Name = "lbl_empname";
            this.lbl_empname.Size = new System.Drawing.Size(174, 18);
            this.lbl_empname.TabIndex = 2;
            this.lbl_empname.Text = "EMPLOYEE NAME :";
            // 
            // lbl_empcity
            // 
            this.lbl_empcity.AutoSize = true;
            this.lbl_empcity.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_empcity.ForeColor = System.Drawing.Color.Blue;
            this.lbl_empcity.Location = new System.Drawing.Point(46, 140);
            this.lbl_empcity.Name = "lbl_empcity";
            this.lbl_empcity.Size = new System.Drawing.Size(165, 18);
            this.lbl_empcity.TabIndex = 3;
            this.lbl_empcity.Text = "EMPLOYEE CITY :";
            // 
            // lbl_empage
            // 
            this.lbl_empage.AutoSize = true;
            this.lbl_empage.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_empage.ForeColor = System.Drawing.Color.Blue;
            this.lbl_empage.Location = new System.Drawing.Point(46, 179);
            this.lbl_empage.Name = "lbl_empage";
            this.lbl_empage.Size = new System.Drawing.Size(159, 18);
            this.lbl_empage.TabIndex = 4;
            this.lbl_empage.Text = "EMPLOYEE AGE :";
            // 
            // lbl_emppassword
            // 
            this.lbl_emppassword.AutoSize = true;
            this.lbl_emppassword.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_emppassword.ForeColor = System.Drawing.Color.Blue;
            this.lbl_emppassword.Location = new System.Drawing.Point(46, 215);
            this.lbl_emppassword.Name = "lbl_emppassword";
            this.lbl_emppassword.Size = new System.Drawing.Size(177, 18);
            this.lbl_emppassword.TabIndex = 5;
            this.lbl_emppassword.Text = "ENTER PASSWORD :";
            // 
            // txt_empid
            // 
            this.txt_empid.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_empid.ForeColor = System.Drawing.Color.Red;
            this.txt_empid.Location = new System.Drawing.Point(261, 43);
            this.txt_empid.Name = "txt_empid";
            this.txt_empid.Size = new System.Drawing.Size(342, 25);
            this.txt_empid.TabIndex = 6;
            // 
            // txt_empname
            // 
            this.txt_empname.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_empname.ForeColor = System.Drawing.Color.Red;
            this.txt_empname.Location = new System.Drawing.Point(261, 85);
            this.txt_empname.Name = "txt_empname";
            this.txt_empname.Size = new System.Drawing.Size(342, 25);
            this.txt_empname.TabIndex = 7;
            this.txt_empname.TextChanged += new System.EventHandler(this.txt_empname_TextChanged);
            // 
            // txt_empage
            // 
            this.txt_empage.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_empage.ForeColor = System.Drawing.Color.Red;
            this.txt_empage.Location = new System.Drawing.Point(261, 172);
            this.txt_empage.Name = "txt_empage";
            this.txt_empage.Size = new System.Drawing.Size(342, 25);
            this.txt_empage.TabIndex = 9;
            // 
            // txt_emppassword
            // 
            this.txt_emppassword.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_emppassword.ForeColor = System.Drawing.Color.Red;
            this.txt_emppassword.Location = new System.Drawing.Point(261, 208);
            this.txt_emppassword.Name = "txt_emppassword";
            this.txt_emppassword.PasswordChar = '*';
            this.txt_emppassword.Size = new System.Drawing.Size(342, 25);
            this.txt_emppassword.TabIndex = 10;
            // 
            // btn_reset
            // 
            this.btn_reset.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_reset.ForeColor = System.Drawing.Color.Red;
            this.btn_reset.Location = new System.Drawing.Point(473, 283);
            this.btn_reset.Name = "btn_reset";
            this.btn_reset.Size = new System.Drawing.Size(130, 61);
            this.btn_reset.TabIndex = 11;
            this.btn_reset.Text = "RESET";
            this.btn_reset.UseVisualStyleBackColor = true;
            this.btn_reset.Click += new System.EventHandler(this.btn_reset_Click);
            // 
            // btn_findemp
            // 
            this.btn_findemp.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_findemp.ForeColor = System.Drawing.Color.Red;
            this.btn_findemp.Location = new System.Drawing.Point(185, 283);
            this.btn_findemp.Name = "btn_findemp";
            this.btn_findemp.Size = new System.Drawing.Size(124, 61);
            this.btn_findemp.TabIndex = 12;
            this.btn_findemp.Text = "FIND EMPLOYEE";
            this.btn_findemp.UseVisualStyleBackColor = true;
            this.btn_findemp.Click += new System.EventHandler(this.btn_findemp_Click);
            // 
            // btn_updateemp
            // 
            this.btn_updateemp.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_updateemp.ForeColor = System.Drawing.Color.Red;
            this.btn_updateemp.Location = new System.Drawing.Point(328, 283);
            this.btn_updateemp.Name = "btn_updateemp";
            this.btn_updateemp.Size = new System.Drawing.Size(120, 61);
            this.btn_updateemp.TabIndex = 13;
            this.btn_updateemp.Text = "UPDATE EMPLOYEE";
            this.btn_updateemp.UseVisualStyleBackColor = true;
            this.btn_updateemp.Click += new System.EventHandler(this.btn_updateemp_Click);
            // 
            // cmb_empcity
            // 
            this.cmb_empcity.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_empcity.ForeColor = System.Drawing.Color.Black;
            this.cmb_empcity.FormattingEnabled = true;
            this.cmb_empcity.Location = new System.Drawing.Point(261, 137);
            this.cmb_empcity.Name = "cmb_empcity";
            this.cmb_empcity.Size = new System.Drawing.Size(346, 25);
            this.cmb_empcity.TabIndex = 14;
            this.cmb_empcity.SelectedIndexChanged += new System.EventHandler(this.cmb_empcity_SelectedIndexChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(635, 374);
            this.Controls.Add(this.cmb_empcity);
            this.Controls.Add(this.btn_updateemp);
            this.Controls.Add(this.btn_findemp);
            this.Controls.Add(this.btn_reset);
            this.Controls.Add(this.txt_emppassword);
            this.Controls.Add(this.txt_empage);
            this.Controls.Add(this.txt_empname);
            this.Controls.Add(this.txt_empid);
            this.Controls.Add(this.lbl_emppassword);
            this.Controls.Add(this.lbl_empage);
            this.Controls.Add(this.lbl_empcity);
            this.Controls.Add(this.lbl_empname);
            this.Controls.Add(this.lbl_empid);
            this.Controls.Add(this.btn_addemp);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_addemp;
        private System.Windows.Forms.Label lbl_empid;
        private System.Windows.Forms.Label lbl_empname;
        private System.Windows.Forms.Label lbl_empcity;
        private System.Windows.Forms.Label lbl_empage;
        private System.Windows.Forms.Label lbl_emppassword;
        private System.Windows.Forms.TextBox txt_empid;
        private System.Windows.Forms.TextBox txt_empname;
        private System.Windows.Forms.TextBox txt_empage;
        private System.Windows.Forms.TextBox txt_emppassword;
        private System.Windows.Forms.Button btn_reset;
        private System.Windows.Forms.Button btn_findemp;
        private System.Windows.Forms.Button btn_updateemp;
        private System.Windows.Forms.ComboBox cmb_empcity;
    }
}

