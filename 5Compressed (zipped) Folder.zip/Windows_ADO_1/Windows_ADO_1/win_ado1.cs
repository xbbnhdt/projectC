﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Windows_ADO_1
{
    class win_ado1
    {
        public int employeeid { get; set; }
        public string employeename { get; set; }
        public string employeecity { get; set; }
        public int employeeage { get; set; }
        public string employeepassword { get; set; }


    }
}
