﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;


namespace Windows_ADO_1
{
    class win_ado1_Employee_dal
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        public bool addemployee(frm_employeesearch obj)
        {
            return true;
        }

    }
}
