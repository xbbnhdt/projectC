﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;


namespace Windows_ADO_1
{
    public partial class frm_employeesearch : Form
    {

        SqlConnection con = new
            SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        public frm_employeesearch()
        {
            InitializeComponent();
        }

        private void btn_show_Click(object sender, EventArgs e)
        {
            SqlDataAdapter data = new SqlDataAdapter("select * from employees", con);
            DataSet ds = new DataSet();
            data.Fill(ds, "emp");
            dg_employees.DataSource = ds.Tables["emp"];
        }

        private void btn_searchemp_Click(object sender, EventArgs e)
        {
            SqlDataAdapter data_employees = new SqlDataAdapter("select * from employees where employeecity = @city",con);
            data_employees.SelectCommand.Parameters.AddWithValue("@city", cmb_city.Text);
            DataSet ds = new DataSet();
            data_employees.Fill(ds, "emp");
            if (ds.Tables["emp"].Rows.Count == 0)
            {
                MessageBox.Show("no results found");
            }
            else
            {
                dg_employees.DataSource = ds.Tables["emp"];
            }
        }

        private void cmb_city_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void frm_employeesearch_Load(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand con_cities = new SqlCommand("select cityname from city", con);
            SqlDataReader dr = con_cities.ExecuteReader();
            while (dr.Read())
            {
                cmb_city.Items.Add(dr.GetString(0));
            }


            con.Close();
        }
    }
}
