﻿namespace Windows_ADO_1
{
    partial class frm_employeesearch
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_show = new System.Windows.Forms.Button();
            this.dg_employees = new System.Windows.Forms.DataGridView();
            this.btn_searchemp = new System.Windows.Forms.Button();
            this.cmb_city = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.dg_employees)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_show
            // 
            this.btn_show.Location = new System.Drawing.Point(67, 12);
            this.btn_show.Name = "btn_show";
            this.btn_show.Size = new System.Drawing.Size(173, 23);
            this.btn_show.TabIndex = 0;
            this.btn_show.Text = "SHOW EMPLOYEES";
            this.btn_show.UseVisualStyleBackColor = true;
            this.btn_show.Click += new System.EventHandler(this.btn_show_Click);
            // 
            // dg_employees
            // 
            this.dg_employees.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg_employees.Location = new System.Drawing.Point(32, 180);
            this.dg_employees.Name = "dg_employees";
            this.dg_employees.Size = new System.Drawing.Size(674, 318);
            this.dg_employees.TabIndex = 1;
            // 
            // btn_searchemp
            // 
            this.btn_searchemp.Location = new System.Drawing.Point(67, 41);
            this.btn_searchemp.Name = "btn_searchemp";
            this.btn_searchemp.Size = new System.Drawing.Size(173, 23);
            this.btn_searchemp.TabIndex = 2;
            this.btn_searchemp.Text = "SEARCH EMPLOYEES";
            this.btn_searchemp.UseVisualStyleBackColor = true;
            this.btn_searchemp.Click += new System.EventHandler(this.btn_searchemp_Click);
            // 
            // cmb_city
            // 
            this.cmb_city.FormattingEnabled = true;
            this.cmb_city.Location = new System.Drawing.Point(255, 43);
            this.cmb_city.Name = "cmb_city";
            this.cmb_city.Size = new System.Drawing.Size(121, 21);
            this.cmb_city.TabIndex = 4;
            this.cmb_city.SelectedIndexChanged += new System.EventHandler(this.cmb_city_SelectedIndexChanged);
            // 
            // frm_employeesearch
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 526);
            this.Controls.Add(this.cmb_city);
            this.Controls.Add(this.btn_searchemp);
            this.Controls.Add(this.dg_employees);
            this.Controls.Add(this.btn_show);
            this.Name = "frm_employeesearch";
            this.Text = "SEARCH EMPLOYEES";
            this.Load += new System.EventHandler(this.frm_employeesearch_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dg_employees)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_show;
        private System.Windows.Forms.DataGridView dg_employees;
        private System.Windows.Forms.Button btn_searchemp;
        private System.Windows.Forms.ComboBox cmb_city;
    }
}