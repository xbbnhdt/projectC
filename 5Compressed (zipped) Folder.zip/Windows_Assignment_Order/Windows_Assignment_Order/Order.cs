﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Windows_Assignment_Order
{
    public class Order 
    {


       int itemprice, orderid, itemqty, itemid; 
        DateTime date; 
        string customername, payment,deliveryaddress, delivercity; 
        public Order(int itemprice, int orderid, int itemqty, int itemid, string customername,  string deliveryaddress) 
        { 
            this.deliveryaddress = deliveryaddress; 
        
          
            this.itemid = itemid; 
            this.orderid = orderid; 
            this.customername = customername; 
            
            this.itemprice = itemprice; 
            this.itemqty = itemqty; 
        }   

        public int getorderValue() 
        { 
            int value = itemqty * itemprice;
            return value;
        }

    }
}

