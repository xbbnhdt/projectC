﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Windows_Assignment_Order
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public void btn_placeorder_Click(object sender, EventArgs e)
        {
           
            if (txt_customername.Text == "")
            {
                MessageBox.Show("please enter customername!");
            }
            else if (txt_orderid.Text == "")
            {
                MessageBox.Show("please enter order id");
            }
            else if (cmb_itemid.Text == "")
            {
                MessageBox.Show("please choose item id");
            }
            else if (txt_itemqty.Text == "")
            {
                MessageBox.Show("please enter item quantity!");
            }
            else if (txt_itemprice.Text == "")
            {
                MessageBox.Show("please enter item price!");
            }
            else if (txt_deliveraddress.Text == "")
            {
                MessageBox.Show("please enter delivery address");
            }
            else if (cmb_choosecity.Text == "")
            {
                MessageBox.Show("please choose a city");
            }
            else if (txt_orderdate.Text == "")
            {
                MessageBox.Show("please enter date");
            }
            else if (rdb_cash.Checked == false && rdb_credit.Checked == false && rdb_debit.Checked == false && rdb_netbank.Checked == false )
            {
                MessageBox.Show("please choose payment mode");
            
            }

            else
            {


                MessageBox.Show("order placed!! thanks for shopping");


                int itemprice = Convert.ToInt32(txt_itemprice.Text);
                int orderid = Convert.ToInt32(txt_orderid.Text);
                int itemqty = Convert.ToInt32(txt_itemqty.Text);
                int itemid = Convert.ToInt32(cmb_itemid.Text);
                string customername = txt_customername.Text;
                string deliveryaddress = txt_deliveraddress.Text;

                Order obj = new Order(itemprice, orderid, itemqty, itemid, customername, deliveryaddress);
                int i = obj.getorderValue();
                MessageBox.Show("Order AMOUNT:" + i);
            }
            
        }

        private void btn_reset_Click(object sender, EventArgs e)
        {
           
            txt_customername.Text = "";
            txt_orderid.Text = "";
            cmb_itemid.Text = "";
            txt_itemqty.Text = "";
            txt_itemprice.Text = "";
            txt_deliveraddress.Text = "";
            cmb_choosecity.Text = "";
            txt_orderdate.Text = "";
            rdb_cash.Checked = false;
            rdb_credit.Checked = false;
            rdb_debit.Checked = false;
            rdb_netbank.Checked = false;

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            cmb_itemid.Items.Add("1001");
            cmb_itemid.Items.Add("1002");
            cmb_itemid.Items.Add("1003");
            cmb_itemid.Items.Add("1004");
            cmb_itemid.Items.Add("1005");
            cmb_choosecity.Items.Add("CHENNAI");
            cmb_choosecity.Items.Add("COCHIN");
            cmb_choosecity.Items.Add("HYDERABAD");
            cmb_choosecity.Items.Add("BANGALORE");
            cmb_choosecity.Items.Add("MUMBAI");
            cmb_choosecity.Items.Add("AHMEDABAD");
            cmb_choosecity.Items.Add("PUNE");
            cmb_choosecity.Items.Add("DELHI");
           
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}


