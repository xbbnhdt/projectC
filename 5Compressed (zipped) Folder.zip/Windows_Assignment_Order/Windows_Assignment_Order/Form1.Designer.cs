﻿namespace Windows_Assignment_Order
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_customername = new System.Windows.Forms.TextBox();
            this.lbl_customername = new System.Windows.Forms.Label();
            this.lbl_orderid = new System.Windows.Forms.Label();
            this.lbl_itemid = new System.Windows.Forms.Label();
            this.lbl_itemqty = new System.Windows.Forms.Label();
            this.lbl_itemprice = new System.Windows.Forms.Label();
            this.lbl_deliveraddress = new System.Windows.Forms.Label();
            this.txt_orderid = new System.Windows.Forms.TextBox();
            this.txt_itemqty = new System.Windows.Forms.TextBox();
            this.txt_itemprice = new System.Windows.Forms.TextBox();
            this.txt_deliveraddress = new System.Windows.Forms.TextBox();
            this.cmb_itemid = new System.Windows.Forms.ComboBox();
            this.lbl_ordercity = new System.Windows.Forms.Label();
            this.lbl_orderdate = new System.Windows.Forms.Label();
            this.lbl_paymentoption = new System.Windows.Forms.Label();
            this.txt_orderdate = new System.Windows.Forms.TextBox();
            this.rdb_debit = new System.Windows.Forms.RadioButton();
            this.rdb_credit = new System.Windows.Forms.RadioButton();
            this.rdb_netbank = new System.Windows.Forms.RadioButton();
            this.rdb_cash = new System.Windows.Forms.RadioButton();
            this.cmb_choosecity = new System.Windows.Forms.ComboBox();
            this.btn_placeorder = new System.Windows.Forms.Button();
            this.btn_reset = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txt_customername
            // 
            this.txt_customername.BackColor = System.Drawing.Color.LavenderBlush;
            this.txt_customername.Font = new System.Drawing.Font("Rockwell", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_customername.Location = new System.Drawing.Point(149, 53);
            this.txt_customername.Name = "txt_customername";
            this.txt_customername.Size = new System.Drawing.Size(121, 20);
            this.txt_customername.TabIndex = 0;
            // 
            // lbl_customername
            // 
            this.lbl_customername.AutoSize = true;
            this.lbl_customername.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_customername.Location = new System.Drawing.Point(27, 60);
            this.lbl_customername.Name = "lbl_customername";
            this.lbl_customername.Size = new System.Drawing.Size(115, 13);
            this.lbl_customername.TabIndex = 1;
            this.lbl_customername.Text = "CUSTOMER NAME";
            // 
            // lbl_orderid
            // 
            this.lbl_orderid.AutoSize = true;
            this.lbl_orderid.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_orderid.Location = new System.Drawing.Point(27, 86);
            this.lbl_orderid.Name = "lbl_orderid";
            this.lbl_orderid.Size = new System.Drawing.Size(68, 13);
            this.lbl_orderid.TabIndex = 2;
            this.lbl_orderid.Text = "ORDER ID";
            // 
            // lbl_itemid
            // 
            this.lbl_itemid.AutoSize = true;
            this.lbl_itemid.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_itemid.Location = new System.Drawing.Point(27, 116);
            this.lbl_itemid.Name = "lbl_itemid";
            this.lbl_itemid.Size = new System.Drawing.Size(54, 13);
            this.lbl_itemid.TabIndex = 3;
            this.lbl_itemid.Text = "ITEM ID";
            // 
            // lbl_itemqty
            // 
            this.lbl_itemqty.AutoSize = true;
            this.lbl_itemqty.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_itemqty.Location = new System.Drawing.Point(27, 143);
            this.lbl_itemqty.Name = "lbl_itemqty";
            this.lbl_itemqty.Size = new System.Drawing.Size(104, 13);
            this.lbl_itemqty.TabIndex = 4;
            this.lbl_itemqty.Text = "ITEM QUANTITY";
            // 
            // lbl_itemprice
            // 
            this.lbl_itemprice.AutoSize = true;
            this.lbl_itemprice.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_itemprice.Location = new System.Drawing.Point(27, 176);
            this.lbl_itemprice.Name = "lbl_itemprice";
            this.lbl_itemprice.Size = new System.Drawing.Size(78, 13);
            this.lbl_itemprice.TabIndex = 5;
            this.lbl_itemprice.Text = "ITEM PRICE";
            // 
            // lbl_deliveraddress
            // 
            this.lbl_deliveraddress.AutoSize = true;
            this.lbl_deliveraddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_deliveraddress.Location = new System.Drawing.Point(27, 208);
            this.lbl_deliveraddress.Name = "lbl_deliveraddress";
            this.lbl_deliveraddress.Size = new System.Drawing.Size(131, 13);
            this.lbl_deliveraddress.TabIndex = 6;
            this.lbl_deliveraddress.Text = "DELIVERY ADDRESS";
            // 
            // txt_orderid
            // 
            this.txt_orderid.BackColor = System.Drawing.Color.LavenderBlush;
            this.txt_orderid.Font = new System.Drawing.Font("Rockwell", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_orderid.Location = new System.Drawing.Point(149, 79);
            this.txt_orderid.Name = "txt_orderid";
            this.txt_orderid.Size = new System.Drawing.Size(121, 20);
            this.txt_orderid.TabIndex = 7;
            // 
            // txt_itemqty
            // 
            this.txt_itemqty.BackColor = System.Drawing.Color.LavenderBlush;
            this.txt_itemqty.Font = new System.Drawing.Font("Rockwell", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_itemqty.Location = new System.Drawing.Point(149, 136);
            this.txt_itemqty.Name = "txt_itemqty";
            this.txt_itemqty.Size = new System.Drawing.Size(121, 20);
            this.txt_itemqty.TabIndex = 9;
            // 
            // txt_itemprice
            // 
            this.txt_itemprice.BackColor = System.Drawing.Color.LavenderBlush;
            this.txt_itemprice.Font = new System.Drawing.Font("Rockwell", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_itemprice.Location = new System.Drawing.Point(149, 169);
            this.txt_itemprice.Name = "txt_itemprice";
            this.txt_itemprice.Size = new System.Drawing.Size(121, 20);
            this.txt_itemprice.TabIndex = 10;
            // 
            // txt_deliveraddress
            // 
            this.txt_deliveraddress.BackColor = System.Drawing.Color.LavenderBlush;
            this.txt_deliveraddress.Font = new System.Drawing.Font("Rockwell", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_deliveraddress.Location = new System.Drawing.Point(148, 201);
            this.txt_deliveraddress.Name = "txt_deliveraddress";
            this.txt_deliveraddress.Size = new System.Drawing.Size(121, 20);
            this.txt_deliveraddress.TabIndex = 11;
            // 
            // cmb_itemid
            // 
            this.cmb_itemid.BackColor = System.Drawing.Color.LavenderBlush;
            this.cmb_itemid.Font = new System.Drawing.Font("Rockwell", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_itemid.FormattingEnabled = true;
            this.cmb_itemid.Location = new System.Drawing.Point(149, 108);
            this.cmb_itemid.Name = "cmb_itemid";
            this.cmb_itemid.Size = new System.Drawing.Size(121, 21);
            this.cmb_itemid.TabIndex = 12;
            // 
            // lbl_ordercity
            // 
            this.lbl_ordercity.AutoSize = true;
            this.lbl_ordercity.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ordercity.Location = new System.Drawing.Point(27, 245);
            this.lbl_ordercity.Name = "lbl_ordercity";
            this.lbl_ordercity.Size = new System.Drawing.Size(90, 13);
            this.lbl_ordercity.TabIndex = 13;
            this.lbl_ordercity.Text = "CHOOSE CITY";
            // 
            // lbl_orderdate
            // 
            this.lbl_orderdate.AutoSize = true;
            this.lbl_orderdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_orderdate.Location = new System.Drawing.Point(27, 283);
            this.lbl_orderdate.Name = "lbl_orderdate";
            this.lbl_orderdate.Size = new System.Drawing.Size(88, 13);
            this.lbl_orderdate.TabIndex = 14;
            this.lbl_orderdate.Text = "ORDER DATE";
            // 
            // lbl_paymentoption
            // 
            this.lbl_paymentoption.AutoSize = true;
            this.lbl_paymentoption.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_paymentoption.Location = new System.Drawing.Point(27, 320);
            this.lbl_paymentoption.Name = "lbl_paymentoption";
            this.lbl_paymentoption.Size = new System.Drawing.Size(106, 13);
            this.lbl_paymentoption.TabIndex = 15;
            this.lbl_paymentoption.Text = "PAYMENT MODE";
            // 
            // txt_orderdate
            // 
            this.txt_orderdate.BackColor = System.Drawing.Color.LavenderBlush;
            this.txt_orderdate.Font = new System.Drawing.Font("Rockwell", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_orderdate.Location = new System.Drawing.Point(149, 276);
            this.txt_orderdate.Name = "txt_orderdate";
            this.txt_orderdate.Size = new System.Drawing.Size(121, 20);
            this.txt_orderdate.TabIndex = 16;
            // 
            // rdb_debit
            // 
            this.rdb_debit.AutoSize = true;
            this.rdb_debit.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdb_debit.Location = new System.Drawing.Point(149, 320);
            this.rdb_debit.Name = "rdb_debit";
            this.rdb_debit.Size = new System.Drawing.Size(100, 17);
            this.rdb_debit.TabIndex = 17;
            this.rdb_debit.TabStop = true;
            this.rdb_debit.Text = "DEBIT CARD";
            this.rdb_debit.UseVisualStyleBackColor = true;
            // 
            // rdb_credit
            // 
            this.rdb_credit.AutoSize = true;
            this.rdb_credit.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdb_credit.Location = new System.Drawing.Point(270, 320);
            this.rdb_credit.Name = "rdb_credit";
            this.rdb_credit.Size = new System.Drawing.Size(109, 17);
            this.rdb_credit.TabIndex = 18;
            this.rdb_credit.TabStop = true;
            this.rdb_credit.Text = "CREDIT CARD";
            this.rdb_credit.UseVisualStyleBackColor = true;
            // 
            // rdb_netbank
            // 
            this.rdb_netbank.AutoSize = true;
            this.rdb_netbank.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdb_netbank.Location = new System.Drawing.Point(149, 355);
            this.rdb_netbank.Name = "rdb_netbank";
            this.rdb_netbank.Size = new System.Drawing.Size(109, 17);
            this.rdb_netbank.TabIndex = 19;
            this.rdb_netbank.TabStop = true;
            this.rdb_netbank.Text = "NET BANKING";
            this.rdb_netbank.UseVisualStyleBackColor = true;
            // 
            // rdb_cash
            // 
            this.rdb_cash.AutoSize = true;
            this.rdb_cash.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdb_cash.Location = new System.Drawing.Point(270, 355);
            this.rdb_cash.Name = "rdb_cash";
            this.rdb_cash.Size = new System.Drawing.Size(145, 17);
            this.rdb_cash.TabIndex = 20;
            this.rdb_cash.TabStop = true;
            this.rdb_cash.Text = "CASH ON DELIVERY";
            this.rdb_cash.UseVisualStyleBackColor = true;
            // 
            // cmb_choosecity
            // 
            this.cmb_choosecity.BackColor = System.Drawing.Color.LavenderBlush;
            this.cmb_choosecity.Font = new System.Drawing.Font("Rockwell", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_choosecity.FormattingEnabled = true;
            this.cmb_choosecity.Location = new System.Drawing.Point(149, 237);
            this.cmb_choosecity.Name = "cmb_choosecity";
            this.cmb_choosecity.Size = new System.Drawing.Size(121, 21);
            this.cmb_choosecity.TabIndex = 21;
            // 
            // btn_placeorder
            // 
            this.btn_placeorder.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_placeorder.Location = new System.Drawing.Point(86, 405);
            this.btn_placeorder.Name = "btn_placeorder";
            this.btn_placeorder.Size = new System.Drawing.Size(131, 34);
            this.btn_placeorder.TabIndex = 22;
            this.btn_placeorder.Text = "PLACE ORDER";
            this.btn_placeorder.UseVisualStyleBackColor = true;
            this.btn_placeorder.Click += new System.EventHandler(this.btn_placeorder_Click);
            // 
            // btn_reset
            // 
            this.btn_reset.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_reset.Location = new System.Drawing.Point(443, 405);
            this.btn_reset.Name = "btn_reset";
            this.btn_reset.Size = new System.Drawing.Size(129, 34);
            this.btn_reset.TabIndex = 23;
            this.btn_reset.Text = "RESET";
            this.btn_reset.UseVisualStyleBackColor = true;
            this.btn_reset.Click += new System.EventHandler(this.btn_reset_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Thistle;
            this.label1.Font = new System.Drawing.Font("Segoe Marker", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Purple;
            this.label1.Location = new System.Drawing.Point(241, 7);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(145, 38);
            this.label1.TabIndex = 24;
            this.label1.Text = "MY ApaNa";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(649, 473);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_reset);
            this.Controls.Add(this.btn_placeorder);
            this.Controls.Add(this.cmb_choosecity);
            this.Controls.Add(this.rdb_cash);
            this.Controls.Add(this.rdb_netbank);
            this.Controls.Add(this.rdb_credit);
            this.Controls.Add(this.rdb_debit);
            this.Controls.Add(this.txt_orderdate);
            this.Controls.Add(this.lbl_paymentoption);
            this.Controls.Add(this.lbl_orderdate);
            this.Controls.Add(this.lbl_ordercity);
            this.Controls.Add(this.cmb_itemid);
            this.Controls.Add(this.txt_deliveraddress);
            this.Controls.Add(this.txt_itemprice);
            this.Controls.Add(this.txt_itemqty);
            this.Controls.Add(this.txt_orderid);
            this.Controls.Add(this.lbl_deliveraddress);
            this.Controls.Add(this.lbl_itemprice);
            this.Controls.Add(this.lbl_itemqty);
            this.Controls.Add(this.lbl_itemid);
            this.Controls.Add(this.lbl_orderid);
            this.Controls.Add(this.lbl_customername);
            this.Controls.Add(this.txt_customername);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_customername;
        private System.Windows.Forms.Label lbl_customername;
        private System.Windows.Forms.Label lbl_orderid;
        private System.Windows.Forms.Label lbl_itemid;
        private System.Windows.Forms.Label lbl_itemqty;
        private System.Windows.Forms.Label lbl_itemprice;
        private System.Windows.Forms.Label lbl_deliveraddress;
        private System.Windows.Forms.TextBox txt_orderid;
        private System.Windows.Forms.TextBox txt_itemqty;
        private System.Windows.Forms.TextBox txt_itemprice;
        private System.Windows.Forms.TextBox txt_deliveraddress;
        private System.Windows.Forms.ComboBox cmb_itemid;
        private System.Windows.Forms.Label lbl_ordercity;
        private System.Windows.Forms.Label lbl_orderdate;
        private System.Windows.Forms.Label lbl_paymentoption;
        private System.Windows.Forms.TextBox txt_orderdate;
        private System.Windows.Forms.RadioButton rdb_debit;
        private System.Windows.Forms.RadioButton rdb_credit;
        private System.Windows.Forms.RadioButton rdb_netbank;
        private System.Windows.Forms.RadioButton rdb_cash;
        private System.Windows.Forms.ComboBox cmb_choosecity;
        private System.Windows.Forms.Button btn_placeorder;
        private System.Windows.Forms.Button btn_reset;
        private System.Windows.Forms.Label label1;
    }
}

