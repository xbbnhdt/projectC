﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Wpf_DataBinding
{
    class Customers
    {

       public int CustomerID {set;get;}
       public string CustomerName {set;get;}
       public string CustomerEmail {set;get;}
       public string  CustomerPassword {set;get;}
    }
}
