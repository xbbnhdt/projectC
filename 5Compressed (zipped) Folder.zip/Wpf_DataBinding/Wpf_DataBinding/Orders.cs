﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Wpf_DataBinding
{
    class Orders
    {
       public int OrderID {set;get;}
       public int CustomerID {set;get;}
       public DateTime OrderDate {set;get;}
       public string OrderAddress {set;get;}
       public int ProductID {set;get;}
       public int ProductPrice {set;get;}
       public int ProductQTY { set; get; }

    }
}
