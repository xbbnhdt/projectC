﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Wpf_DataBinding
{
    /// <summary>
    /// Interaction logic for Window_Placeorder.xaml
    /// </summary>
    public partial class Window_Placeorder : Window
    {
        public Window_Placeorder()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            ProductsDAL dal = new ProductsDAL();
            lst_products.ItemsSource = dal.GetProducts();
        }

        private void btn_placeorder_Click(object sender, RoutedEventArgs e)
        {
            Product p = lst_products.SelectedItem as Product;
            if (p != null)
            {
                OrdersDAL dal = new OrdersDAL();
                Orders ord = new Orders();
                ord.ProductID = p.ProductID;
                ord.ProductPrice = p.ProductPrice;
                ord.ProductQTY = Convert.ToInt32(txt_item_qty.Text);
                ord.OrderAddress = txt_address.Text;
                ord.CustomerID = Convert.ToInt32(App.Current.Properties["cid"]);
                dal.PlaceOrder(ord);
                MessageBox.Show("ORDER:" + ord.OrderID + "PLACED SUCCESSFULLY!");

            }
            else
            {
                MessageBox.Show("SELECT A PRODUCT");
            }
        }
    }
}
