﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Wpf_DataBinding
{
    class Product
    {
        public int ProductID { set; get; }
        public string ProductName { set; get; }
        public int ProductPrice { set; get; }
        

    }
}
