﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Wpf_DataBinding
{
    /// <summary>
    /// Interaction logic for Window_Show_Orders.xaml
    /// </summary>
    public partial class Window_Show_Orders : Window
    {
        public Window_Show_Orders()
        {
            InitializeComponent();
        }

        private void btn_show_orders_Click(object sender, RoutedEventArgs e)
        {
            OrdersDAL dal = new OrdersDAL();
            int customerid = Convert.ToInt32(App.Current.Properties["cid"]);
            dg_orders.ItemsSource = dal.GerOrders(customerid);

        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

        }
    }
}
