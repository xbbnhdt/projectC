﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;


namespace Wpf_DataBinding
{
    class CustomersDAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);

        public bool Login(Customers obj)
        {
            con.Open();
            SqlCommand con_customer_login = new SqlCommand("select * from customers where CustomerID = @custid and CustomerPassword = @custpswd", con);
            con_customer_login.Parameters.AddWithValue("@custid", obj.CustomerID);
            con_customer_login.Parameters.AddWithValue("@custpswd", obj.CustomerPassword);
            int count = Convert.ToInt32(con_customer_login.ExecuteScalar());
            con.Close();
            if (count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }

           
        }


    }
}
