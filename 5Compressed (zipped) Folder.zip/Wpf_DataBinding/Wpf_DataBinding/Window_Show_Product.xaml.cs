﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Wpf_DataBinding
{
    /// <summary>
    /// Interaction logic for Window_Show_Product.xaml
    /// </summary>
    public partial class Window_Show_Product : Window
    {
        public Window_Show_Product()
        {
            InitializeComponent();
        }

       

        private void btn_find_Click(object sender, RoutedEventArgs e)
        {
            ProductsDAL dal = new ProductsDAL();
            stp_product.DataContext = dal.GetProduct(Convert.ToInt32(txt_pid.Text));
           
        }
    }
}
