﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;


namespace Wpf_DataBinding
{
    class OrdersDAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        public bool PlaceOrder(Orders ord)
        {
            SqlCommand con_order_insert = new SqlCommand("insert orders values(@custid, getdate(), @address, @pid, @price, @qty)",con);
            con_order_insert.Parameters.AddWithValue("custid",ord.CustomerID);
            con_order_insert.Parameters.AddWithValue("@address",ord.OrderAddress);
            con_order_insert.Parameters.AddWithValue("@pid",ord.ProductID);
            con_order_insert.Parameters.AddWithValue("@price",ord.ProductPrice);
            con_order_insert.Parameters.AddWithValue("@qty",ord.ProductQTY);
            con.Open();
            con_order_insert.ExecuteNonQuery();
            SqlCommand con_orderid = new SqlCommand("select @@identity",con);
                int orderid = Convert.ToInt32(con_orderid.ExecuteNonQuery());
            ord.OrderID = orderid;
            con.Close();
            return true;}       
        public List<Orders>GerOrders(int customerID)
        {
            List<Orders> orderlist = new List<Orders>();
            SqlCommand con_orders = new SqlCommand("select * from orders where customerid = @custid", con);
            con_orders.Parameters.AddWithValue("@custid", customerID);
            con.Open();
            SqlDataReader dr = con_orders.ExecuteReader();
            while (dr.Read())
            {                Orders ord = new Orders();
                ord.OrderID = dr.GetInt32(0);
                ord.CustomerID = dr.GetInt32(1);
                ord.OrderDate = dr.GetDateTime(2);
                ord.OrderAddress = dr.GetString(3);
                ord.ProductID = dr.GetInt32(4);
                ord.ProductPrice = dr.GetInt32(5);
                ord.ProductQTY = dr.GetInt32(6);
                orderlist.Add(ord);
            }
            con.Close();
            return orderlist;




        }

    }
}
