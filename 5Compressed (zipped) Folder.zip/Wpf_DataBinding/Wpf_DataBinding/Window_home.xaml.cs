﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Wpf_DataBinding
{
    /// <summary>
    /// Interaction logic for Window_home.xaml
    /// </summary>
    public partial class Window_home : Window
    {
        public Window_home()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            txt_customerid.Text = App.Current.Properties["cid"].ToString();
            
        }

        private void btn_find_product_Click(object sender, RoutedEventArgs e)
        {
            Window_Show_Product obj = new Window_Show_Product();
            obj.Show();
        }

        private void btn_placeorder_Click(object sender, RoutedEventArgs e)
        {
            Window_Placeorder obj = new Window_Placeorder();
            obj.Show();
        }

        private void btn_showorder_Click(object sender, RoutedEventArgs e)
        {
            Window_Show_Orders obj = new Window_Show_Orders();
            obj.Show();
        }
    }
}
