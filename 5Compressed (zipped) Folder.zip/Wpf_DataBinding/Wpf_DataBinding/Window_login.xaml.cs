﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Wpf_DataBinding
{
    /// <summary>
    /// Interaction logic for Window_login.xaml
    /// </summary>
    public partial class Window_login : Window
    {
        public Window_login()
        {
            InitializeComponent();
        }

        private void btn_login_Click(object sender, RoutedEventArgs e)
        {
            CustomersDAL dal = new CustomersDAL();
            Customers c = new Customers();
            c.CustomerID = Convert.ToInt32(txt_login.Text);
            c.CustomerPassword = txt_password.Password;

            if (dal.Login(c))
            {

                MessageBox.Show("VALID CUSTOMER");
                App.Current.Properties.Add("cid", txt_login.Text);
               
                Window_home home = new Window_home();
                home.Show();
                this.Close();


            }

            else
            {

                MessageBox.Show("INVALID USER");
            }



        }
    }
}
