﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Wpf_Assignment_1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btn_login_Click(object sender, RoutedEventArgs e)
        {
            if (txt_loginid.Text == "shri" && txt_password.Password == "prashu@1996")
            {
                MessageBox.Show("VALID USER");
                App.Current.Properties.Add("shri", txt_loginid.Text);
                wpf_Home obj = new wpf_Home();
                obj.Show();
                this.Close();
            }
            else
            {
                MessageBox.Show("INVALID USER");
            }
        }
    }
}
