﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = Convert.ToInt32(Console.ReadLine());
        int x=1;
        for(int i = (x-1); i<n; i++)
            {
            for(int j=(n-x); j>=0;j++)
                {

                    if ((i + j) == (n - 1))
                    {
                        Console.WriteLine("#");

                    }
                }

            }

        x++;
        }
        }
    }

