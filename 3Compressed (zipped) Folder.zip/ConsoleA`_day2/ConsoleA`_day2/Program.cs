﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleA__day2
{
    class Program
    {
        static void Main(string[] args)
        {

            bool flag;

            do
            {
                Console.WriteLine("ENTER YOUR NAME:");
                string customername = Console.ReadLine();

                
                Console.WriteLine("ENTER THE ITEM ID:");
                int itemid = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("ENTER ITEM QUANTITY:");
                int itemqty = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("ENTER THE ITEM PRICE:");
                int itemprice = Convert.ToInt32(Console.ReadLine());

                Order obj = new Order(itemid, itemqty, customername, itemprice);

                Console.WriteLine("orderid:"+obj.porderid);
                Console.WriteLine("ordervalue:"+obj.pordervalue);

                Console.WriteLine("do you want to order again?");
                Console.WriteLine("true/false");

                flag = Convert.ToBoolean(Console.ReadLine());

            } while (flag);
                Console.WriteLine(Order.count);
                Console.ReadLine();


            


        }              
        }
    }

