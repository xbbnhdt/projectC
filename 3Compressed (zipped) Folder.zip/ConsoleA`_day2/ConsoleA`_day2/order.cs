﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleA__day2
{
    class Order
    {

        int orderid;
        int itemid;
        int itemqty;
        int itemprice;
        int ordervalue;
        string customername;

       public static int count;

        public Order(int itemid,int itemqty,string customername,int itemprice)
        {
            count++;
            this.orderid = count;
            this.itemid = itemid;
            this.itemqty = itemqty;
            this.itemprice = itemprice;
            this.customername = customername;
        }

        public int porderid
        {

            get
            {

                return orderid;
            }
        }

        public int pordervalue
        {

            get
            {

                return itemprice * itemqty;

            }

        }



                



    }
}
