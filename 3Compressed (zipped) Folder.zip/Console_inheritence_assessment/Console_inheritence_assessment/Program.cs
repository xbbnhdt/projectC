﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_inheritence_assessment
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("enter customername");
            string CustomerName = Console.ReadLine(); 
            Console.WriteLine("enter item price");
            int ItemPrice= Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter item quantity");
            int ItemQTY= Convert.ToInt32(Console.ReadLine());
          Console.WriteLine("enter type");
            string type= Console.ReadLine();
            Order obj;
            if (type=="Order")
            {
                obj=new Order(CustomerName,ItemQTY,ItemPrice);
            }
            else
            {
                obj=new Order_Overseas(CustomerName,ItemQTY,ItemPrice);
            }


            Console.WriteLine(obj.GetOrderAmount());
            Console.ReadLine();

        }
    }
}
