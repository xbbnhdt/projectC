﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_inheritence_assessment
{
    class Order
    {
        string CustomerName;
        int ItemQTY;
        int ItemPrice;
        int OrderId;
        protected double BasicSalary;

        public static int count;
        public Order(string CustomerName, int ItemQTY, int ItemPrice)
        {
            count++;
            this.OrderId=count;
            this.CustomerName=CustomerName;
            this.ItemQTY=ItemQTY;
            this.ItemPrice=ItemPrice;
        }

        public virtual double GetOrderAmount()
        {

            BasicSalary= ItemQTY * ItemPrice;
            return BasicSalary;
        
        }
    }
}
