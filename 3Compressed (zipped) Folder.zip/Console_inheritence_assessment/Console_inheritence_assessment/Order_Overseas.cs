﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_inheritence_assessment
{
    class Order_Overseas : Order
    {
      public Order_Overseas(string CustomerName, int ItemQTY, int ItemPrice) : base(CustomerName,ItemQTY,ItemPrice)
    {


    }

        public sealed override double GetOrderAmount()
        {
            return base.GetOrderAmount()-500;
        }



    }
}
