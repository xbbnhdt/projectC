﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_interface
{
    class ProductA : iTransport , iTesting
    {

        public string pid;
        public string pname;
        public string address;
        public string customername;

        public void play()
        { }
        public void stop()
        { }
        public string GetAddress()
        {
            return pid + " " + pname + " " + address;
        }

        public string GetCustomerAddress()
        {
            return address;
        }

        public bool Run()
        {
            this.play();
            return true;
        }

        public bool Stop()
        {
            this.stop();
            return true;
        }
    }
}
