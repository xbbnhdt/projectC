﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_interface
{
    class ProductB : iTransport , iTesting
    {
        public string productid;
        public string productname;
        public string customeraddress;
        public string customername;
        public string spac_details;

        public void run()
        { }
        public void stop()
        { }
        public string GetCustomerDetails()
        {
            return customername + " " + customeraddress;
        }



        public string GetCustomerAddress()
        {
            return customeraddress;
        }

        public bool Run()
        {
            this.run();
            return true;
        }

        public bool Stop()
        {
            this.stop();
            return true;
        }
    }
}
