﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_interface
{
    class Program
    {
        static void Main(string[] args)
        {

            ProductA a = new ProductA();
            a.pid = "123";
            a.pname = "mobile";
            a.customername = "xyz";
            a.address = "Chennai";

            ProductB b = new ProductB();
            b.productid = "111";
            b.productname = "laptop";
            b.customeraddress = "pune";
            b.customername = "ABC";

            Testing testdept = new Testing();
            bool statusa = testdept.Rec_ProductForTesting(a);
            bool statusb = testdept.Rec_ProductForTesting(b);

            Transport t = new Transport();

            if (statusa == true)
            {
                t.Rec_Product(a);
            }
            else
            {
                Console.WriteLine("PRODUCT NOT OK!");
            }
                if (statusb == true)
                {
                    t.Rec_Product(b);
                }
                else
                {
                    Console.WriteLine("PRODUCT NOT OK!");
                }
                Console.ReadLine();


            }
        }
    }

