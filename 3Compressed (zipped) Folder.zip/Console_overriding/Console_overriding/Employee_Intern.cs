﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_overriding
{
    class Employee_Intern : Employee
    {
        public Employee_Intern(int empid, string empname, int basicsalary)
            : base(empid, empname, basicsalary)

        { }

        public override int Getsalary()
        {
            return basicsalary =15000;
        }

    }
}
