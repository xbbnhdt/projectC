﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_overriding
{
    class Employee_Contract : Employee
    {
        public Employee_Contract(int empid, string empname, int basicsalary)
            : base(empid, empname, basicsalary)
        {
        }
        public sealed override int Getsalary()
        {
            return basicsalary + 1000;
        }
    }
}
