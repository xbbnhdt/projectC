﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_overriding
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter emp id");
            int empid = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter emp name");
            string empname = Console.ReadLine();
            Console.WriteLine("enter emp basic salary");
            int basic = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter employee type");
            string type = Console.ReadLine();
            Employee obj;
            if (type == "Employee")
            {
                obj = new Employee(empid, empname, basic);
            }
            else if (type == "Intern")
            {
                obj = new Employee_Intern(empid, empname, basic);
            }
            else {

                obj = new Employee_Contract(empid, empname, basic);
            }
            
            Console.WriteLine(obj.Getdetails());
            Console.WriteLine(obj.Getwork());
            Console.WriteLine(obj.Getsalary());
            Console.ReadLine();
        }
    }
}
