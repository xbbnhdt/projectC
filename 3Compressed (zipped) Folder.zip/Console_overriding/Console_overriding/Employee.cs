﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_overriding
{
    class Employee
    {
        int empid;
        string empname;
      protected int basicsalary;
        public Employee(int empid, string empname, int basicsalary)
        {
            this.empid = empid;
            this.empname = empname;
            this.basicsalary = basicsalary;
        
        }
        public string Getwork()
        {
            return "Working as Programmer";
        }
        public string Getdetails()
        {
            return empid + " " + empname;
        }
        public virtual int Getsalary()
        {
            int tax=1200;
            return basicsalary+2500-tax;
        }
    }
}
