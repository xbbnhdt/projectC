﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Collections;
namespace Console_Generic
{
    class Program
    {
        static void Main(string[] args)
        {
            Dictionary<int, string> names = new Dictionary<int, string>();//no boxing and unboxing

            names.Add(1001, "abc");
            names.Add(1002, "xyz");

            string str = names[1001];

            Console.WriteLine(str);


            List<int> marks = new List<int>();//mark is list type of integer so no need boxing or unboxing
            marks.Add(80);
            marks.Add(90);

            int x = marks[0];
            Console.WriteLine(x);
            Console.WriteLine(marks.Count);


            foreach (int i in marks)
            {
                Console.WriteLine(i);

            }

                
                
                /*
            ArrayList list = new ArrayList();
            list.Add("abc");//0
            list.Add(1500);//1
            list.Add(true);//2
            int x = Convert.ToInt32(list[1]);
            string str = list[0].ToString();
            bool b = Convert.ToBoolean(list[2]);
            Console.WriteLine(x);
            Console.WriteLine(str);
            Console.WriteLine(b);
             * */
            /*
            Test obj = new Test();
            int i = obj.GetData<int>(100);
            string str = obj.GetData<string>("hello");
            Console.WriteLine(i);
            Console.WriteLine(str);
           */
             Console.ReadLine();                                                                                                                    
            
        }
    }
}
