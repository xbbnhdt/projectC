﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_Delegates
{
    class Program
    {
        static void Main(string[] args)
        {
            EventTesting obj = new EventTesting();
            obj.bind();
           
            obj.fire();
            //Test t = new Test();
            //t.bind();
            Console.ReadLine();
        }
    }
}
