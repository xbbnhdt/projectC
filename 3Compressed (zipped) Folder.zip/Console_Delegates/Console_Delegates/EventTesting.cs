﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_Delegates
{
    class EventTesting
    {
        public delegate void delevent(string msg);
        public event delevent evnt;

        public void fire()
        {
           // if (evnt != null)
            {
                evnt("hello from event");
            }
        }


        public void call(string str)
        {
            Console.WriteLine("call:" + str);
        }
        public void bind()
        {
            delevent obj = new delevent(call);
            this.evnt += obj;

        }
    }




}