﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_Delegates
{
    class Test
    {
        public delegate void del(string str);

        public void getdata(string msg)
        {
            Console.WriteLine("getdata: " + msg);
        }
        public void setdata(string str)
        {
            Console.WriteLine("setdata: " + str);
            
        }

        public void bind()
        {
            int i = 234;
            del obj = new del(getdata);
            obj += new del(setdata);
            obj += delegate(string str)//anonymous function supported by delegate
            {
                Console.WriteLine(str);
                Console.WriteLine(i);
            };

            obj("hello");
        }
    }
}
