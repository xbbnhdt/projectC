﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_GC
{
    interface iDisposable
    {
        public void Dispose()
        { }
    }
}
