﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_GC
{
    class Xyz : iDisposable
    {

        public void Dispose()
        {
            
          Console.WriteLine("Disposed");
        
        
        }
    }
   
    }

