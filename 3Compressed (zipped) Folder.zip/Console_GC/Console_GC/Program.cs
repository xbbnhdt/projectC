﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_GC
{
    class Program
    {
        static void Main(string[] args)
        {

            using (Xyz obj = new Xyz())
            { 
            
            
            
            
            }
            /*
            int i = 0;
            int marks = 0;
            while (i < 5)
            {
                Test obj = new Test();
                if (i == 3)
                {
                    GC.SuppressFinalize(obj);//finalize means GC..command to GC to not call finalize/GC.
                }
                obj = null;
                i++;
                marks = 5000;//objects
            }

            GC.Collect();
             * */
            
          Console.ReadLine();
        }
    }
}
