﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_singleton_day2
{
    class Manager
    {

        string managername;
        int managerid;
        public string pmanagername
        {
            get
        {
            return managername;
        }
        }
        public int pmanagerid
        {
            get{
                return managerid;
            }
        }
        public Manager(string managername, int managerid)
        {
        this.managername=managername;
        this.managerid=managerid;
        }

        static Manager m;
        public static Manager GetManager()
        {
            if (m==null)
            {
           m = new Manager("aba",12);
            }
            return m;
           
        }
    }
}
